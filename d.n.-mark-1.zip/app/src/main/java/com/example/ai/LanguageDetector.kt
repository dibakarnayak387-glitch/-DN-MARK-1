package com.example.ai

import com.example.data.model.AgentLanguage
import com.example.data.model.LanguagePreference

object LanguageDetector {

    private val hindiHints = setOf(
        "kya", "kaise", "mera", "meri", "karo", "batao", "mausam", "chalao",
        "kholo", "bhejo", "namaste", "dhanyavad", "aaj", "kal", "mujhe", "yaad", "dilana",
        "madad", "samay", "hindi", "paani", "baat", "karna"
    )

    private val odiaHints = setOf(
        "namaskar", "kemiti", "achha", "achhi", "mora", "mate", "kaha", "khole", "khola",
        "odia", "panipaga", "aaji", "kali", "dhanyabad", "sahajya", "karantu", "pathao",
        "bujhila", "mane", "rakhantu"
    )

    fun resolveLanguage(text: String, preference: LanguagePreference): AgentLanguage {
        when (preference) {
            LanguagePreference.ENGLISH -> return AgentLanguage.ENGLISH
            LanguagePreference.HINDI -> return AgentLanguage.HINDI
            LanguagePreference.ODIA -> return AgentLanguage.ODIA
            LanguagePreference.AUTO -> Unit
        }
        return detectFromText(text)
    }

    fun detectFromText(text: String): AgentLanguage {
        if (text.isBlank()) return AgentLanguage.ENGLISH

        var devanagariCount = 0
        var odiaCount = 0
        for (ch in text) {
            when (ch.code) {
                in 0x0900..0x097F -> devanagariCount++
                in 0x0B00..0x0B7F -> odiaCount++
            }
        }
        if (odiaCount > 0 && odiaCount >= devanagariCount) return AgentLanguage.ODIA
        if (devanagariCount > 0) return AgentLanguage.HINDI

        val words = text.lowercase()
            .split(Regex("[^a-z]+"))
            .filter { it.length >= 3 }

        val odiaMatches = words.count { it in odiaHints }
        val hindiMatches = words.count { it in hindiHints }
        if (odiaMatches >= 2 || (odiaMatches == 1 && hindiMatches == 0 && words.size <= 5)) {
            return AgentLanguage.ODIA
        }
        if (hindiMatches >= 2 || (hindiMatches == 1 && words.size <= 5)) {
            return AgentLanguage.HINDI
        }
        return AgentLanguage.ENGLISH
    }
}
