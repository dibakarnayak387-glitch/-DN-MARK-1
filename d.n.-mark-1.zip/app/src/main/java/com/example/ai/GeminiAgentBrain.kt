package com.example.ai

import android.util.Log
import com.example.data.model.AgentIntentType
import com.example.data.model.AgentLanguage
import com.example.data.model.AgentPlanResponse
import com.example.data.model.ConversationMessage
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.data.model.MemoryProposal
import com.example.data.model.PlannedStep
import com.example.data.model.UserReminder
import com.example.tools.AndroidToolRegistry
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "GeminiAgentBrain"
private const val MODEL_NAME = "gemini-3.8-flash"
private const val TIMEOUT_MS = 60_000L

interface AgentBrain {
    suspend fun planRequest(
        userPrompt: String,
        preferredLanguage: AgentLanguage,
        recentHistory: List<ConversationMessage>,
        memories: List<MemoryItem>,
        pendingReminders: List<UserReminder>,
        toolCatalog: String,
        allowedToolNames: List<String>
    ): Result<AgentPlanResponse>

    suspend fun synthesizeExecutionReport(
        originalPrompt: String,
        language: AgentLanguage,
        stepOutcomeLines: List<String>,
        pendingRemindersCount: Int
    ): Result<String>
}

class GeminiAgentBrain(
    private val toolRegistry: AndroidToolRegistry
) : AgentBrain {

    private fun buildPlanSchema(allowedTools: List<String>): Schema {
        val stepSchema = Schema.obj(
            properties = mapOf(
                "title" to Schema.string(description = "Short human-readable step title"),
                "toolName" to Schema.enumeration(
                    values = allowedTools,
                    description = "Exact registered Android tool name"
                ),
                "query" to Schema.string(description = "Search query or topic if applicable", nullable = true),
                "appName" to Schema.string(description = "Target app name if opening an app", nullable = true),
                "recipient" to Schema.string(description = "Intended recipient name if messaging", nullable = true),
                "messageText" to Schema.string(description = "Prepared message or text to speak/share", nullable = true),
                "location" to Schema.string(description = "City name for weather if mentioned", nullable = true),
                "timeLabel" to Schema.string(description = "Time or schedule label for reminders/tasks", nullable = true),
                "notes" to Schema.string(description = "Additional notes or caption", nullable = true),
                "requiredPermission" to Schema.string(description = "Android permission if needed, else empty", nullable = true),
                "requiresConfirmation" to Schema.boolean(description = "True if user approval is required before executing"),
                "expectedResult" to Schema.string(description = "Expected verified outcome of this step")
            ),
            optionalProperties = listOf(
                "query", "appName", "recipient", "messageText",
                "location", "timeLabel", "notes", "requiredPermission"
            )
        )

        val memoryProposalSchema = Schema.obj(
            properties = mapOf(
                "category" to Schema.enumeration(
                    values = listOf("PREFERENCE", "INSTRUCTION", "FACT", "ROUTINE", "CONTEXT"),
                    description = "Memory classification"
                ),
                "title" to Schema.string(description = "Concise memory title"),
                "content" to Schema.string(description = "Personal preference, fact, or instruction to save only if approved")
            )
        )

        return Schema.obj(
            properties = mapOf(
                "detectedLanguage" to Schema.enumeration(
                    values = listOf("en", "hi", "or"),
                    description = "Detected language code: en (English), hi (Hindi), or or (Odia)"
                ),
                "intentType" to Schema.enumeration(
                    values = listOf("DIRECT_ANSWER", "CLARIFY", "EXECUTE_PLAN", "PROPOSE_MEMORY"),
                    description = "Whether to answer directly, ask clarifying questions, execute a multi-step tool plan, or propose saving memory"
                ),
                "assistantReply" to Schema.string(
                    description = "Natural, concise response in the user's detected language explaining the plan, answer, or clarifying question"
                ),
                "taskTitle" to Schema.string(description = "Concise title for the planned task", nullable = true),
                "taskDescription" to Schema.string(description = "Full task description", nullable = true),
                "requiresConfirmation" to Schema.boolean(
                    description = "True if any step sends/prepares a message, shares a photo, creates reminders/tasks, or needs explicit approval"
                ),
                "steps" to Schema.array(
                    items = stepSchema,
                    description = "Ordered list of Android tool steps (empty when intentType is DIRECT_ANSWER or CLARIFY)"
                ),
                "memoryProposal" to memoryProposalSchema,
                "proactiveSuggestions" to Schema.array(
                    items = Schema.string(),
                    description = "Up to 3 short, useful next-step prompt suggestions in the user's language"
                )
            ),
            optionalProperties = listOf("taskTitle", "taskDescription", "memoryProposal")
        )
    }

    private val plannerModel by lazy {
        val allowedTools = toolRegistry.allowedToolNames
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.25f
                responseMimeType = "application/json"
                responseSchema = buildPlanSchema(allowedTools)
            },
            systemInstruction = content {
                text(
                    """
                    You are D.N. Mark 1 ("Jarvis"), an elite, reliable Android mobile work agent.
                    Core principles:
                    1. Multilingual mastery: Detect English ("en"), Hindi ("hi"), and Odia ("or"). Always write assistantReply and proactiveSuggestions in the exact same language as the user. Use Devanagari for Hindi and Odia script (ଓଡ଼ିଆ) for Odia when the user speaks or writes in those languages.
                    2. Never fake actions or claim you executed a tool before the Android Tool Registry runs it.
                    3. Break multi-part instructions into ordered steps using ONLY the registered tools in the tool catalog.
                    4. If a request is ambiguous or missing key priorities (e.g., "help me organize my day" with no tasks yet), set intentType="CLARIFY" and ask 1-2 crisp questions while offering helpful suggestions.
                    5. Confirmation safety: Set requiresConfirmation=true for prepare_whatsapp_message, open_camera_share, android_share_sheet, create_reminder, create_local_task, or any sensitive user-facing action. Read-only telemetry (check_battery, check_charging_status, get_weather, get_device_info, youtube_search, internet_search) can run with requiresConfirmation=false unless combined with sensitive steps.
                    6. Privacy & Smart Memory: If the user shares a lasting preference, personal fact, or standing instruction ("remember that I live in Cuttack", "always reply in Odia"), populate memoryProposal so the UI can ask explicit user consent before saving.
                    7. Never attempt arbitrary code execution, shell commands, or unauthorized accessibility automation.
                    """.trimIndent()
                )
            }
        )
    }

    private val synthesisModel by lazy {
        Firebase.ai.generativeModel(
            modelName = MODEL_NAME,
            generationConfig = generationConfig {
                temperature = 0.35f
            },
            systemInstruction = content {
                text(
                    """
                    You are D.N. Mark 1 ("Jarvis"), reporting verified Android tool execution results.
                    - Respond strictly in the requested language (English, Hindi in Devanagari, or Odia in ଓଡ଼ିଆ script).
                    - Report ONLY what actually succeeded or failed based on the verified tool logs provided. Never fabricate success.
                    - If any step failed or required permission, explain clearly why and suggest the safest recovery step.
                    - Keep the response crisp, well-structured, and voice-friendly (2-5 concise sentences or tight bullets).
                    """.trimIndent()
                )
            }
        )
    }

    override suspend fun planRequest(
        userPrompt: String,
        preferredLanguage: AgentLanguage,
        recentHistory: List<ConversationMessage>,
        memories: List<MemoryItem>,
        pendingReminders: List<UserReminder>,
        toolCatalog: String,
        allowedToolNames: List<String>
    ): Result<AgentPlanResponse> {
        return try {
            val memoryBlock = if (memories.isEmpty()) {
                "None saved yet."
            } else {
                memories.take(12).joinToString("\n") { "- [${it.category}] ${it.title}: ${it.content}" }
            }

            val historyBlock = if (recentHistory.isEmpty()) {
                "No prior turns."
            } else {
                recentHistory.takeLast(8).joinToString("\n") { "${it.role}: ${it.text.take(400)}" }
            }

            val reminderBlock = if (pendingReminders.isEmpty()) {
                "No open reminders."
            } else {
                pendingReminders.filter { !it.completed }.take(6)
                    .joinToString("\n") { "- ${it.title} (${it.scheduledTimeLabel})" }
            }

            val prompt = """
                User Language Hint: ${preferredLanguage.displayName} (${preferredLanguage.code})

                Registered Android Tool Catalog:
                $toolCatalog

                Approved User Memories:
                $memoryBlock

                Open User Reminders / Day Plan:
                $reminderBlock

                Recent Conversation Context:
                $historyBlock

                Current User Instruction:
                $userPrompt
            """.trimIndent()

            val response = withTimeout(TIMEOUT_MS) {
                plannerModel.generateContent(prompt)
            }
            val rawJson = response.text?.takeIf { it.isNotBlank() }
                ?: return Result.failure(IllegalStateException("Gemini returned an empty planning response."))

            Result.success(parsePlanJson(rawJson, preferredLanguage))
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini planning timed out", e)
            Result.failure(Exception("AI planning timed out after 60 seconds. Please check your connection and retry."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini planning failed", e)
            Result.failure(e)
        }
    }

    override suspend fun synthesizeExecutionReport(
        originalPrompt: String,
        language: AgentLanguage,
        stepOutcomeLines: List<String>,
        pendingRemindersCount: Int
    ): Result<String> {
        return try {
            val prompt = """
                Target Language: ${language.displayName} (${language.code})
                Original User Request: $originalPrompt
                Open Reminders Count: $pendingRemindersCount

                Verified Step Execution Log:
                ${stepOutcomeLines.joinToString("\n")}

                Provide a clear, verified summary of what succeeded, any failures or pending user actions, and one helpful next step if appropriate.
            """.trimIndent()

            val response = withTimeout(TIMEOUT_MS) {
                synthesisModel.generateContent(prompt)
            }
            val text = response.text?.trim()
            if (!text.isNullOrEmpty()) {
                Result.success(text)
            } else {
                Result.failure(IllegalStateException("Gemini returned an empty summary."))
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini synthesis timed out", e)
            Result.failure(Exception("Summary generation timed out. Showing verified step outcomes."))
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini synthesis failed", e)
            Result.failure(e)
        }
    }

    internal fun parsePlanJson(rawJson: String, fallbackLanguage: AgentLanguage): AgentPlanResponse {
        val json = JSONObject(rawJson)
        val detectedLang = AgentLanguage.fromCode(
            json.optString("detectedLanguage", fallbackLanguage.code)
        )
        val intentType = AgentIntentType.safeParse(json.optString("intentType", "DIRECT_ANSWER"))
        val assistantReply = json.optString("assistantReply", "").trim()
            .ifEmpty { "Ready to assist." }
        val taskTitle = json.optString("taskTitle", "").trim()
        val taskDesc = json.optString("taskDescription", "").trim()
        var requiresConfirmation = json.optBoolean("requiresConfirmation", false)

        val steps = mutableListOf<PlannedStep>()
        val stepsArray = json.optJSONArray("steps")
        if (stepsArray != null) {
            for (i in 0 until stepsArray.length().coerceAtMost(25)) {
                val obj = stepsArray.optJSONObject(i) ?: continue
                val toolName = obj.optString("toolName", "").trim()
                if (toolName.isEmpty()) continue
                val registeredTool = toolRegistry.getTool(toolName)
                val stepConfirm = obj.optBoolean("requiresConfirmation", false) ||
                    (registeredTool?.requiresConfirmation == true)
                if (stepConfirm) requiresConfirmation = true

                steps.add(
                    PlannedStep(
                        stepIndex = i,
                        title = obj.optString("title", registeredTool?.displayName ?: toolName).trim(),
                        toolName = toolName,
                        query = obj.optStringOrNull("query"),
                        appName = obj.optStringOrNull("appName"),
                        recipient = obj.optStringOrNull("recipient"),
                        messageText = obj.optStringOrNull("messageText"),
                        location = obj.optStringOrNull("location"),
                        timeLabel = obj.optStringOrNull("timeLabel"),
                        notes = obj.optStringOrNull("notes"),
                        requiredPermission = obj.optStringOrNull("requiredPermission")
                            ?: registeredTool?.requiredPermissions?.firstOrNull(),
                        requiresConfirmation = stepConfirm,
                        expectedResult = obj.optString("expectedResult", "").trim()
                    )
                )
            }
        }

        val memoryProposal = json.optJSONObject("memoryProposal")?.let { memObj ->
            val mTitle = memObj.optString("title", "").trim()
            val mContent = memObj.optString("content", "").trim()
            if (mTitle.isNotEmpty() && mContent.isNotEmpty()) {
                MemoryProposal(
                    category = MemoryCategory.safeParse(memObj.optString("category", "CONTEXT")),
                    title = mTitle,
                    content = mContent,
                    language = detectedLang
                )
            } else null
        }

        val suggestions = mutableListOf<String>()
        val sugArray = json.optJSONArray("proactiveSuggestions")
        if (sugArray != null) {
            for (i in 0 until sugArray.length().coerceAtMost(3)) {
                val s = sugArray.optString(i, "").trim()
                if (s.isNotEmpty()) suggestions.add(s)
            }
        }

        return AgentPlanResponse(
            detectedLanguage = detectedLang,
            intentType = intentType,
            assistantReply = assistantReply,
            taskTitle = taskTitle.ifEmpty { if (steps.isNotEmpty()) steps.first().title else "" },
            taskDescription = taskDesc,
            requiresConfirmation = requiresConfirmation,
            steps = steps,
            memoryProposal = memoryProposal,
            proactiveSuggestions = suggestions
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val value = optString(key, "").trim()
        return value.takeIf { it.isNotEmpty() && !it.equals("null", ignoreCase = true) }
    }
}
