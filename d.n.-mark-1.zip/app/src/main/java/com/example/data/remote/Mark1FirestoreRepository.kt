package com.example.data.remote

import android.content.Context
import com.example.R
import com.example.data.model.AgentLanguage
import com.example.data.model.AgentTask
import com.example.data.model.ConversationMessage
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.data.model.MessageRole
import com.example.data.model.TaskStatus
import com.example.data.model.UserReminder
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.UUID

class Mark1FirestoreRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        db = FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUserId: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        if (expectedUserId != null && uid != expectedUserId) {
            throw IllegalStateException("Signed-in user mismatch; refusing cross-user Firestore operation.")
        }
        return uid
    }

    private fun generateSafeDocId(prefix: String): String {
        val token = UUID.randomUUID().toString().replace("-", "").take(18)
        return "${prefix}_${token}"
    }

    private fun conversationsRef(uid: String) =
        db.collection("users").document(uid).collection("conversations")

    private fun tasksRef(uid: String) =
        db.collection("users").document(uid).collection("tasks")

    private fun memoriesRef(uid: String) =
        db.collection("users").document(uid).collection("memories")

    private fun remindersRef(uid: String) =
        db.collection("users").document(uid).collection("reminders")

    // --- CONVERSATIONS ---

    fun observeConversations(userId: String): Flow<List<ConversationMessage>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/conversations"
        emitAll(
            conversationsRef(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        ConversationMessage::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedBy { it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, uid, path)
                    throw error
                }
        )
    }

    suspend fun addConversationMessage(
        userId: String,
        role: MessageRole,
        text: String,
        language: AgentLanguage,
        linkedTaskId: String? = null
    ): Result<String> {
        val docId = generateSafeDocId("msg")
        val path = "users/$userId/conversations/$docId"
        return try {
            val uid = requireUserId(userId)
            val cleanText = text.trim().take(12000)
            require(cleanText.isNotEmpty()) { "Message text cannot be empty." }

            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "role" to role.name,
                "text" to cleanText,
                "language" to language.code,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            linkedTaskId?.trim()?.takeIf { it.isNotEmpty() }?.let {
                payload["linkedTaskId"] = it.take(128)
            }

            conversationsRef(uid).document(docId).set(payload).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun clearConversationHistory(userId: String): Result<Unit> {
        val path = "users/$userId/conversations"
        return try {
            val uid = requireUserId(userId)
            val docs = conversationsRef(uid).get().await().documents
            if (docs.isNotEmpty()) {
                val batch = db.batch()
                docs.forEach { batch.delete(it.reference) }
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- AGENT TASKS ---

    fun observeTasks(userId: String): Flow<List<AgentTask>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/tasks"
        emitAll(
            tasksRef(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        AgentTask::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                }
                .catch { error ->
                    logStreamErrorIfActive(error, uid, path)
                    throw error
                }
        )
    }

    suspend fun createTask(
        userId: String,
        taskId: String = generateSafeDocId("task"),
        title: String,
        description: String,
        language: AgentLanguage,
        status: TaskStatus,
        stepsCount: Int,
        stepsSummary: List<String>,
        requiresConfirmation: Boolean
    ): Result<String> {
        val path = "users/$userId/tasks/$taskId"
        return try {
            val uid = requireUserId(userId)
            val safeTitle = title.trim().ifEmpty { "Agent Task" }.take(200)
            val safeDesc = description.trim().take(2000)
            val boundedCount = stepsCount.coerceIn(0, 25)
            val boundedSummary = stepsSummary.take(25).map { it.take(300) }

            val payload = mapOf(
                "userId" to uid,
                "title" to safeTitle,
                "description" to safeDesc,
                "language" to language.code,
                "status" to status.name,
                "progressPercent" to 0,
                "stepsCount" to boundedCount,
                "completedStepsCount" to 0,
                "stepsSummary" to boundedSummary,
                "requiresConfirmation" to requiresConfirmation,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            tasksRef(uid).document(taskId).set(payload).await()
            Result.success(taskId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateTaskProgress(
        userId: String,
        taskId: String,
        status: TaskStatus,
        progressPercent: Int,
        completedStepsCount: Int,
        stepsSummary: List<String>,
        summary: String? = null,
        errorMessage: String? = null,
        requiresConfirmation: Boolean? = null
    ): Result<Unit> {
        val path = "users/$userId/tasks/$taskId"
        return try {
            val uid = requireUserId(userId)
            require(taskId.isNotBlank()) { "Task ID must not be blank." }

            val updates = mutableMapOf<String, Any?>(
                "status" to status.name,
                "progressPercent" to progressPercent.coerceIn(0, 100),
                "completedStepsCount" to completedStepsCount.coerceIn(0, 25),
                "stepsSummary" to stepsSummary.take(25).map { it.take(300) },
                "updatedAt" to FieldValue.serverTimestamp()
            )
            if (summary != null) {
                updates["summary"] = summary.take(4000)
            }
            updates["errorMessage"] = errorMessage?.take(1000)
            if (requiresConfirmation != null) {
                updates["requiresConfirmation"] = requiresConfirmation
            }

            tasksRef(uid).document(taskId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteTask(userId: String, taskId: String): Result<Unit> {
        val path = "users/$userId/tasks/$taskId"
        return try {
            val uid = requireUserId(userId)
            tasksRef(uid).document(taskId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- SMART MEMORIES ---

    fun observeMemories(userId: String): Flow<List<MemoryItem>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/memories"
        emitAll(
            memoriesRef(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        MemoryItem::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareByDescending<MemoryItem> { it.pinned }
                            .thenByDescending { it.updatedAt ?: it.createdAt ?: Timestamp(0, 0) }
                    )
                }
                .catch { error ->
                    logStreamErrorIfActive(error, uid, path)
                    throw error
                }
        )
    }

    suspend fun createApprovedMemory(
        userId: String,
        category: MemoryCategory,
        title: String,
        content: String,
        language: AgentLanguage,
        pinned: Boolean = false
    ): Result<String> {
        val docId = generateSafeDocId("mem")
        val path = "users/$userId/memories/$docId"
        return try {
            val uid = requireUserId(userId)
            val safeTitle = title.trim().take(160)
            val safeContent = content.trim().take(2000)
            require(safeTitle.isNotEmpty() && safeContent.isNotEmpty()) {
                "Memory title and content must not be empty."
            }

            val payload = mapOf(
                "userId" to uid,
                "category" to category.name,
                "title" to safeTitle,
                "content" to safeContent,
                "language" to language.code,
                "approvedByUser" to true,
                "pinned" to pinned,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            memoriesRef(uid).document(docId).set(payload).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun updateMemory(
        userId: String,
        memoryId: String,
        category: MemoryCategory,
        title: String,
        content: String,
        language: AgentLanguage,
        pinned: Boolean
    ): Result<Unit> {
        val path = "users/$userId/memories/$memoryId"
        return try {
            val uid = requireUserId(userId)
            val safeTitle = title.trim().take(160)
            val safeContent = content.trim().take(2000)
            require(memoryId.isNotBlank() && safeTitle.isNotEmpty() && safeContent.isNotEmpty()) {
                "Invalid memory update payload."
            }

            memoriesRef(uid).document(memoryId).update(
                mapOf(
                    "category" to category.name,
                    "title" to safeTitle,
                    "content" to safeContent,
                    "language" to language.code,
                    "pinned" to pinned,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteMemory(userId: String, memoryId: String): Result<Unit> {
        val path = "users/$userId/memories/$memoryId"
        return try {
            val uid = requireUserId(userId)
            memoriesRef(uid).document(memoryId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    // --- REMINDERS & DAY PLAN ---

    fun observeReminders(userId: String): Flow<List<UserReminder>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/reminders"
        emitAll(
            remindersRef(uid)
                .snapshots()
                .map { snapshot ->
                    snapshot.toObjects(
                        UserReminder::class.java,
                        DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                    ).sortedWith(
                        compareBy<UserReminder> { it.completed }
                            .thenByDescending { it.createdAt ?: Timestamp(0, 0) }
                    )
                }
                .catch { error ->
                    logStreamErrorIfActive(error, uid, path)
                    throw error
                }
        )
    }

    suspend fun createReminder(
        userId: String,
        title: String,
        notes: String?,
        scheduledTimeLabel: String
    ): Result<String> {
        val docId = generateSafeDocId("rem")
        val path = "users/$userId/reminders/$docId"
        return try {
            val uid = requireUserId(userId)
            val safeTitle = title.trim().take(200)
            val safeTime = scheduledTimeLabel.trim().ifEmpty { "Today" }.take(100)
            require(safeTitle.isNotEmpty()) { "Reminder title cannot be empty." }

            val payload = mutableMapOf<String, Any>(
                "userId" to uid,
                "title" to safeTitle,
                "scheduledTimeLabel" to safeTime,
                "completed" to false,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
            notes?.trim()?.takeIf { it.isNotEmpty() }?.let {
                payload["notes"] = it.take(1000)
            }

            remindersRef(uid).document(docId).set(payload).await()
            Result.success(docId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, path)
            Result.failure(e)
        }
    }

    suspend fun toggleReminderCompleted(
        userId: String,
        reminderId: String,
        completed: Boolean
    ): Result<Unit> {
        val path = "users/$userId/reminders/$reminderId"
        return try {
            val uid = requireUserId(userId)
            remindersRef(uid).document(reminderId).update(
                mapOf(
                    "completed" to completed,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, path)
            Result.failure(e)
        }
    }

    suspend fun deleteReminder(userId: String, reminderId: String): Result<Unit> {
        val path = "users/$userId/reminders/$reminderId"
        return try {
            val uid = requireUserId(userId)
            remindersRef(uid).document(reminderId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, path)
            Result.failure(e)
        }
    }

    private fun logStreamErrorIfActive(error: Throwable, uid: String, path: String) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) return
        val exceptionToLog = firestoreError ?: (error as? Exception)
        if (exceptionToLog != null && auth.currentUser?.uid == uid) {
            handleFirestoreError(exceptionToLog, OperationType.LIST, path)
        }
    }
}
