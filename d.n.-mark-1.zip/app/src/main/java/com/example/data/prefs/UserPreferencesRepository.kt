package com.example.data.prefs

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.LanguagePreference
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.mark1DataStore: DataStore<Preferences> by preferencesDataStore(name = "dn_mark1_prefs")

data class UserPreferences(
    val languagePreference: LanguagePreference = LanguagePreference.AUTO,
    val continuousConversation: Boolean = false,
    val wakePhraseFilterEnabled: Boolean = false,
    val autoSpeakResponses: Boolean = true,
    val speechRate: Float = 1.0f,
    val proactiveSuggestionsEnabled: Boolean = true,
    val defaultCity: String = "Bhubaneswar"
)

class UserPreferencesRepository(private val context: Context) {

    private object Keys {
        val LANGUAGE = stringPreferencesKey("language_preference")
        val CONTINUOUS = booleanPreferencesKey("continuous_conversation")
        val WAKE_PHRASE = booleanPreferencesKey("wake_phrase_filter")
        val AUTO_SPEAK = booleanPreferencesKey("auto_speak_responses")
        val SPEECH_RATE = floatPreferencesKey("speech_rate")
        val PROACTIVE = booleanPreferencesKey("proactive_suggestions")
        val DEFAULT_CITY = stringPreferencesKey("default_city")
    }

    val preferencesFlow: Flow<UserPreferences> = context.mark1DataStore.data.map { prefs ->
        UserPreferences(
            languagePreference = LanguagePreference.fromCode(prefs[Keys.LANGUAGE]),
            continuousConversation = prefs[Keys.CONTINUOUS] ?: false,
            wakePhraseFilterEnabled = prefs[Keys.WAKE_PHRASE] ?: false,
            autoSpeakResponses = prefs[Keys.AUTO_SPEAK] ?: true,
            speechRate = (prefs[Keys.SPEECH_RATE] ?: 1.0f).coerceIn(0.6f, 1.6f),
            proactiveSuggestionsEnabled = prefs[Keys.PROACTIVE] ?: true,
            defaultCity = prefs[Keys.DEFAULT_CITY]?.takeIf { it.isNotBlank() } ?: "Bhubaneswar"
        )
    }

    suspend fun setLanguagePreference(pref: LanguagePreference) {
        context.mark1DataStore.edit { it[Keys.LANGUAGE] = pref.code }
    }

    suspend fun setContinuousConversation(enabled: Boolean) {
        context.mark1DataStore.edit { it[Keys.CONTINUOUS] = enabled }
    }

    suspend fun setWakePhraseFilter(enabled: Boolean) {
        context.mark1DataStore.edit { it[Keys.WAKE_PHRASE] = enabled }
    }

    suspend fun setAutoSpeak(enabled: Boolean) {
        context.mark1DataStore.edit { it[Keys.AUTO_SPEAK] = enabled }
    }

    suspend fun setSpeechRate(rate: Float) {
        context.mark1DataStore.edit { it[Keys.SPEECH_RATE] = rate.coerceIn(0.6f, 1.6f) }
    }

    suspend fun setProactiveSuggestions(enabled: Boolean) {
        context.mark1DataStore.edit { it[Keys.PROACTIVE] = enabled }
    }

    suspend fun setDefaultCity(city: String) {
        val cleaned = city.trim().take(80)
        if (cleaned.isNotEmpty()) {
            context.mark1DataStore.edit { it[Keys.DEFAULT_CITY] = cleaned }
        }
    }
}
