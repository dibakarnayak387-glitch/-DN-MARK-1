package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CachedStepEntity::class,
        CachedTaskPlanEntity::class,
        CachedMemoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class Mark1Database : RoomDatabase() {
    abstract fun stepDao(): Mark1StepDao
    abstract fun taskPlanDao(): Mark1TaskPlanDao
    abstract fun memoryCacheDao(): Mark1MemoryCacheDao

    companion object {
        @Volatile
        private var INSTANCE: Mark1Database? = null

        fun getInstance(context: Context): Mark1Database {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    Mark1Database::class.java,
                    "dn_mark1_local.db"
                ).fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
