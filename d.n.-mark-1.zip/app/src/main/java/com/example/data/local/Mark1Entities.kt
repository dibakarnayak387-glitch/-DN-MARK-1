package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cached_steps")
data class CachedStepEntity(
    @PrimaryKey val stepKey: String,
    val taskId: String,
    val userId: String,
    val stepIndex: Int,
    val title: String,
    val toolName: String,
    val query: String?,
    val appName: String?,
    val recipient: String?,
    val messageText: String?,
    val location: String?,
    val timeLabel: String?,
    val notes: String?,
    val requiredPermission: String?,
    val requiresConfirmation: Boolean,
    val expectedResult: String,
    val status: String,
    val actualResult: String?,
    val errorDetail: String?,
    val recoveryNote: String?,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_task_plans")
data class CachedTaskPlanEntity(
    @PrimaryKey val taskId: String,
    val userId: String,
    val title: String,
    val description: String,
    val language: String,
    val originalPrompt: String,
    val status: String,
    val updatedAtMillis: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_memories")
data class CachedMemoryEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val category: String,
    val title: String,
    val content: String,
    val language: String,
    val pinned: Boolean,
    val updatedAtMillis: Long = System.currentTimeMillis()
)
