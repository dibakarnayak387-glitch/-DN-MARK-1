package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface Mark1StepDao {
    @Query("SELECT * FROM cached_steps WHERE userId = :userId ORDER BY updatedAtMillis DESC, stepIndex ASC")
    fun observeStepsForUser(userId: String): Flow<List<CachedStepEntity>>

    @Query("SELECT * FROM cached_steps WHERE taskId = :taskId ORDER BY stepIndex ASC")
    suspend fun getStepsForTask(taskId: String): List<CachedStepEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertSteps(steps: List<CachedStepEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertStep(step: CachedStepEntity)

    @Query("DELETE FROM cached_steps WHERE taskId = :taskId")
    suspend fun deleteStepsForTask(taskId: String)

    @Query("DELETE FROM cached_steps WHERE userId = :userId")
    suspend fun clearStepsForUser(userId: String)
}

@Dao
interface Mark1TaskPlanDao {
    @Query("SELECT * FROM cached_task_plans WHERE taskId = :taskId LIMIT 1")
    suspend fun getTaskPlan(taskId: String): CachedTaskPlanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertTaskPlan(plan: CachedTaskPlanEntity)

    @Query("DELETE FROM cached_task_plans WHERE taskId = :taskId")
    suspend fun deleteTaskPlan(taskId: String)
}

@Dao
interface Mark1MemoryCacheDao {
    @Query("SELECT * FROM cached_memories WHERE userId = :userId ORDER BY pinned DESC, updatedAtMillis DESC")
    fun observeCachedMemories(userId: String): Flow<List<CachedMemoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<CachedMemoryEntity>)

    @Query("DELETE FROM cached_memories WHERE userId = :userId")
    suspend fun clearForUser(userId: String)
}
