package com.example.data.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

enum class AgentLanguage(
    val code: String,
    val displayName: String,
    val nativeLabel: String,
    val bcp47Tag: String
) {
    ENGLISH("en", "English", "English", "en-IN"),
    HINDI("hi", "Hindi", "हिन्दी", "hi-IN"),
    ODIA("or", "Odia", "ଓଡ଼ିଆ", "or-IN");

    companion object {
        fun fromCode(raw: String?): AgentLanguage =
            entries.firstOrNull { it.code.equals(raw?.trim(), ignoreCase = true) } ?: ENGLISH
    }
}

enum class LanguagePreference(val code: String, val label: String) {
    AUTO("auto", "Auto"),
    ENGLISH("en", "EN"),
    HINDI("hi", "हिन्दी"),
    ODIA("or", "ଓଡ଼ିଆ");

    companion object {
        fun fromCode(raw: String?): LanguagePreference =
            entries.firstOrNull { it.code.equals(raw, ignoreCase = true) } ?: AUTO
    }
}

enum class MessageRole {
    USER, ASSISTANT, SYSTEM, TOOL;

    companion object {
        fun safeParse(raw: String?): MessageRole =
            entries.firstOrNull { it.name == raw } ?: ASSISTANT
    }
}

enum class TaskStatus {
    PENDING,
    AWAITING_CONFIRMATION,
    RUNNING,
    COMPLETED,
    FAILED,
    CANCELLED;

    companion object {
        fun safeParse(raw: String?): TaskStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

enum class StepStatus {
    PENDING,
    AWAITING_CONFIRMATION,
    RUNNING,
    VERIFIED,
    FAILED,
    SKIPPED,
    CANCELLED;

    companion object {
        fun safeParse(raw: String?): StepStatus =
            entries.firstOrNull { it.name == raw } ?: PENDING
    }
}

enum class MemoryCategory(val label: String) {
    PREFERENCE("Preference"),
    INSTRUCTION("Instruction"),
    FACT("Fact"),
    ROUTINE("Routine"),
    CONTEXT("Context");

    companion object {
        fun safeParse(raw: String?): MemoryCategory =
            entries.firstOrNull { it.name == raw } ?: CONTEXT
    }
}

enum class AgentCoreState {
    IDLE,
    LISTENING,
    THINKING,
    EXECUTING,
    AWAITING_CONFIRMATION,
    SPEAKING,
    ERROR
}

@Keep
@IgnoreExtraProperties
data class ConversationMessage(
    @DocumentId val id: String = "",
    val userId: String = "",
    val role: String = MessageRole.ASSISTANT.name,
    val text: String = "",
    val language: String = AgentLanguage.ENGLISH.code,
    val linkedTaskId: String? = null,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedRole: MessageRole get() = MessageRole.safeParse(role)
    val parsedLanguage: AgentLanguage get() = AgentLanguage.fromCode(language)
}

@Keep
@IgnoreExtraProperties
data class AgentTask(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val description: String = "",
    val language: String = AgentLanguage.ENGLISH.code,
    val status: String = TaskStatus.PENDING.name,
    val progressPercent: Long = 0L,
    val stepsCount: Long = 0L,
    val completedStepsCount: Long = 0L,
    val stepsSummary: List<String> = emptyList(),
    val summary: String? = null,
    val errorMessage: String? = null,
    val requiresConfirmation: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedStatus: TaskStatus get() = TaskStatus.safeParse(status)
    val parsedLanguage: AgentLanguage get() = AgentLanguage.fromCode(language)
}

@Keep
@IgnoreExtraProperties
data class MemoryItem(
    @DocumentId val id: String = "",
    val userId: String = "",
    val category: String = MemoryCategory.CONTEXT.name,
    val title: String = "",
    val content: String = "",
    val language: String = AgentLanguage.ENGLISH.code,
    val approvedByUser: Boolean = true,
    val pinned: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
) {
    val parsedCategory: MemoryCategory get() = MemoryCategory.safeParse(category)
    val parsedLanguage: AgentLanguage get() = AgentLanguage.fromCode(language)
}

@Keep
@IgnoreExtraProperties
data class UserReminder(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val notes: String? = null,
    val scheduledTimeLabel: String = "",
    val completed: Boolean = false,
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

data class PlannedStep(
    val stepIndex: Int,
    val title: String,
    val toolName: String,
    val query: String? = null,
    val appName: String? = null,
    val recipient: String? = null,
    val messageText: String? = null,
    val location: String? = null,
    val timeLabel: String? = null,
    val notes: String? = null,
    val requiredPermission: String? = null,
    val requiresConfirmation: Boolean = false,
    val expectedResult: String = ""
)

data class MemoryProposal(
    val category: MemoryCategory,
    val title: String,
    val content: String,
    val language: AgentLanguage
)

enum class AgentIntentType {
    DIRECT_ANSWER,
    CLARIFY,
    EXECUTE_PLAN,
    PROPOSE_MEMORY;

    companion object {
        fun safeParse(raw: String?): AgentIntentType =
            entries.firstOrNull { it.name.equals(raw?.trim(), ignoreCase = true) } ?: DIRECT_ANSWER
    }
}

data class AgentPlanResponse(
    val detectedLanguage: AgentLanguage,
    val intentType: AgentIntentType,
    val assistantReply: String,
    val taskTitle: String = "",
    val taskDescription: String = "",
    val requiresConfirmation: Boolean = false,
    val steps: List<PlannedStep> = emptyList(),
    val memoryProposal: MemoryProposal? = null,
    val proactiveSuggestions: List<String> = emptyList()
)

data class PendingTaskPlan(
    val taskId: String,
    val userId: String,
    val title: String,
    val description: String,
    val language: AgentLanguage,
    val steps: List<PlannedStep>,
    val requiresConfirmation: Boolean,
    val originalPrompt: String
)

data class ActivePhotoDraft(
    val uriString: String,
    val caption: String
)

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}
