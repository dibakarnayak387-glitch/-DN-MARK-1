package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.AgentLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale
import java.util.UUID

private const val TAG = "VoiceController"

data class VoiceUiState(
    val isListening: Boolean = false,
    val isSpeaking: Boolean = false,
    val rmsAmplitude: Float = 0f,
    val partialTranscript: String = "",
    val voiceError: String? = null,
    val ttsReady: Boolean = false,
    val ttsLanguageNote: String? = null
)

class VoiceController(
    private val appContext: Context,
    private val onRecognizedCommand: (String) -> Unit
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var speechRecognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null

    private var wakePhraseRequired: Boolean = false
    private var continuousMode: Boolean = false
    private var activeLanguage: AgentLanguage = AgentLanguage.ENGLISH
    private var speechRate: Float = 1.0f

    private val _voiceState = MutableStateFlow(VoiceUiState())
    val voiceState: StateFlow<VoiceUiState> = _voiceState.asStateFlow()

    init {
        initTts()
    }

    private fun initTts() {
        try {
            tts = TextToSpeech(appContext) { status ->
                val ready = status == TextToSpeech.SUCCESS
                _voiceState.value = _voiceState.value.copy(ttsReady = ready)
                if (ready) {
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {
                            _voiceState.value = _voiceState.value.copy(isSpeaking = true)
                        }

                        override fun onDone(utteranceId: String?) {
                            _voiceState.value = _voiceState.value.copy(isSpeaking = false)
                            if (continuousMode) {
                                mainHandler.postDelayed({
                                    if (continuousMode && !_voiceState.value.isListening) {
                                        startListening(activeLanguage, wakePhraseRequired, continuousMode)
                                    }
                                }, 450L)
                            }
                        }

                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            _voiceState.value = _voiceState.value.copy(isSpeaking = false)
                        }
                    })
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "TTS initialization failed", e)
        }
    }

    fun updateSpeechRate(rate: Float) {
        speechRate = rate.coerceIn(0.6f, 1.6f)
        tts?.setSpeechRate(speechRate)
    }

    fun startListening(
        language: AgentLanguage,
        requireWakePhrase: Boolean,
        continuous: Boolean
    ) {
        activeLanguage = language
        wakePhraseRequired = requireWakePhrase
        continuousMode = continuous

        mainHandler.post {
            stopSpeaking()
            if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
                _voiceState.value = _voiceState.value.copy(
                    isListening = false,
                    voiceError = "Android Speech Recognition service is not available on this device."
                )
                return@post
            }

            try {
                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                    setRecognitionListener(createListener())
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, language.bcp47Tag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, language.bcp47Tag)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }

                _voiceState.value = _voiceState.value.copy(
                    isListening = true,
                    partialTranscript = "",
                    voiceError = null,
                    rmsAmplitude = 0.15f
                )
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start SpeechRecognizer", e)
                _voiceState.value = _voiceState.value.copy(
                    isListening = false,
                    rmsAmplitude = 0f,
                    voiceError = "Could not start microphone listening: ${e.localizedMessage}"
                )
            }
        }
    }

    fun stopListening() {
        continuousMode = false
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (e: Exception) {
                Log.w(TAG, "Error stopping SpeechRecognizer: ${e.message}")
            }
            _voiceState.value = _voiceState.value.copy(
                isListening = false,
                rmsAmplitude = 0f,
                partialTranscript = ""
            )
        }
    }

    fun speak(text: String, language: AgentLanguage): Boolean {
        val engine = tts ?: return false
        if (!_voiceState.value.ttsReady || text.isBlank()) return false

        val locale = Locale.forLanguageTag(language.bcp47Tag)
        val availability = engine.isLanguageAvailable(locale)
        var note: String? = null
        if (availability == TextToSpeech.LANG_MISSING_DATA || availability == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Transparent fallback if device lacks Odia/Hindi offline TTS pack
            val fallbackLocale = if (language == AgentLanguage.ODIA) {
                note = "Odia TTS voice pack is not installed on this device; using Hindi/Indian English speech fallback."
                Locale.forLanguageTag("hi-IN")
            } else {
                note = "${language.displayName} TTS voice pack is missing; using English voice fallback."
                Locale.forLanguageTag("en-IN")
            }
            val fbAvail = engine.isLanguageAvailable(fallbackLocale)
            engine.language = if (fbAvail >= TextToSpeech.LANG_AVAILABLE) fallbackLocale else Locale.US
        } else {
            engine.language = locale
        }

        _voiceState.value = _voiceState.value.copy(ttsLanguageNote = note)
        engine.setSpeechRate(speechRate)
        val cleanText = text.replace(Regex("[*#`_]"), "").take(1800)
        val utteranceId = "mark1_${UUID.randomUUID()}"
        val res = engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        return res == TextToSpeech.SUCCESS
    }

    fun stopSpeaking() {
        tts?.stop()
        _voiceState.value = _voiceState.value.copy(isSpeaking = false)
    }

    fun clearVoiceError() {
        _voiceState.value = _voiceState.value.copy(voiceError = null)
    }

    fun release() {
        stopListening()
        stopSpeaking()
        tts?.shutdown()
        tts = null
    }

    private fun createListener(): RecognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            _voiceState.value = _voiceState.value.copy(isListening = true, voiceError = null)
        }

        override fun onBeginningOfSpeech() {}

        override fun onRmsChanged(rmsdB: Float) {
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.08f, 1.0f)
            _voiceState.value = _voiceState.value.copy(rmsAmplitude = normalized)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            _voiceState.value = _voiceState.value.copy(rmsAmplitude = 0.05f)
        }

        override fun onError(error: Int) {
            val errorMessage = when (error) {
                SpeechRecognizer.ERROR_AUDIO -> "Audio recording error."
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network error during voice recognition."
                SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap mic or speak clearly."
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected."
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognizer is busy; retrying."
                else -> "Voice recognition interrupted (code $error)."
            }
            val shouldRestart = continuousMode &&
                (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)

            _voiceState.value = _voiceState.value.copy(
                isListening = false,
                rmsAmplitude = 0f,
                voiceError = if (shouldRestart) null else errorMessage
            )

            if (shouldRestart) {
                mainHandler.postDelayed({
                    if (continuousMode) {
                        startListening(activeLanguage, wakePhraseRequired, continuousMode)
                    }
                }, 600L)
            }
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val transcript = matches?.firstOrNull()?.trim().orEmpty()
            _voiceState.value = _voiceState.value.copy(
                isListening = false,
                rmsAmplitude = 0f,
                partialTranscript = ""
            )

            if (transcript.isNotEmpty()) {
                val command = extractWakePhraseCommand(transcript, wakePhraseRequired)
                if (command != null) {
                    onRecognizedCommand(command)
                } else if (continuousMode) {
                    // Wake phrase not detected; resume listening cleanly
                    mainHandler.postDelayed({
                        if (continuousMode) {
                            startListening(activeLanguage, wakePhraseRequired, continuousMode)
                        }
                    }, 500L)
                } else {
                    _voiceState.value = _voiceState.value.copy(
                        voiceError = "Wake phrase \"Jarvis\" not detected in: \"$transcript\""
                    )
                }
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                .orEmpty()
            if (partial.isNotBlank()) {
                _voiceState.value = _voiceState.value.copy(partialTranscript = partial)
            }
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    companion object {
        private val wakePatterns = listOf(
            "jarvis", "जार्विस", "ଜାର୍ଭିସ୍", "ଜାର୍ଭିସ", "hey jarvis", "ok jarvis"
        )

        /**
         * Parses wake phrase "Jarvis" across English, Hindi, and Odia scripts.
         * When requireWakePhrase is false, strips optional leading "Jarvis" and returns full command.
         */
        fun extractWakePhraseCommand(transcript: String, requireWakePhrase: Boolean): String? {
            val trimmed = transcript.trim()
            if (trimmed.isEmpty()) return null
            val lower = trimmed.lowercase()
            val matchedWake = wakePatterns.firstOrNull { lower.contains(it) }
            if (requireWakePhrase && matchedWake == null) {
                return null
            }
            if (matchedWake != null) {
                val idx = lower.indexOf(matchedWake)
                val after = trimmed.substring(idx + matchedWake.length)
                    .trimStart(',', '.', ':', ' ', '-', '!')
                return after.ifBlank { trimmed }
            }
            return trimmed
        }
    }
}
