package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.local.CachedStepEntity
import com.example.data.model.AgentTask
import com.example.data.model.StepStatus
import com.example.data.model.TaskStatus
import com.example.data.model.UiState
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceHigh
import com.example.ui.theme.GateAmber
import com.example.ui.theme.SapphireBlue
import com.example.ui.theme.VerifiedEmerald

private enum class TaskFilter(val label: String) {
    ALL("All"),
    RUNNING("Running"),
    PENDING("Pending"),
    COMPLETED("Completed"),
    FAILED("Failed")
}

@Composable
fun TasksDashboardScreen(
    tasksState: UiState<List<AgentTask>>,
    localStepsByTask: Map<String, List<CachedStepEntity>>,
    pendingPlanTaskId: String?,
    onApprovePending: () -> Unit,
    onCancelTask: (String) -> Unit,
    onRetryTask: (String) -> Unit,
    onDeleteTask: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedFilter by rememberSaveable { mutableStateOf(TaskFilter.ALL) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    text = "AGENT TASK DASHBOARD",
                    style = MaterialTheme.typography.titleLarge,
                    color = ArcCyan
                )
                Text(
                    text = "Real-time execution timelines, verification logs, cancel & retry controls",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            when (tasksState) {
                is UiState.Loading -> {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = ArcCyan)
                    }
                }

                is UiState.Error -> {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(tasksState.message, color = AlertCrimson)
                    }
                }

                is UiState.Success -> {
                    val allTasks = tasksState.data
                    val runningCount = allTasks.count { it.parsedStatus == TaskStatus.RUNNING }
                    val pendingCount = allTasks.count {
                        it.parsedStatus == TaskStatus.PENDING || it.parsedStatus == TaskStatus.AWAITING_CONFIRMATION
                    }
                    val completedCount = allTasks.count { it.parsedStatus == TaskStatus.COMPLETED }
                    val failedCount = allTasks.count {
                        it.parsedStatus == TaskStatus.FAILED || it.parsedStatus == TaskStatus.CANCELLED
                    }

                    // Telemetry Summary Strip
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TaskMetricCard("Running", runningCount, ArcCyan, Modifier.weight(1f))
                        TaskMetricCard("Pending", pendingCount, GateAmber, Modifier.weight(1f))
                        TaskMetricCard("Verified", completedCount, VerifiedEmerald, Modifier.weight(1f))
                        TaskMetricCard("Issues", failedCount, AlertCrimson, Modifier.weight(1f))
                    }

                    Spacer(Modifier.height(10.dp))

                    // Filter Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TaskFilter.entries.forEach { filter ->
                            FilterChip(
                                selected = selectedFilter == filter,
                                onClick = { selectedFilter = filter },
                                label = { Text(filter.label, style = MaterialTheme.typography.labelMedium) },
                                modifier = Modifier.testTag("task_filter_${filter.name.lowercase()}")
                            )
                        }
                    }

                    val filtered = allTasks.filter { task ->
                        when (selectedFilter) {
                            TaskFilter.ALL -> true
                            TaskFilter.RUNNING -> task.parsedStatus == TaskStatus.RUNNING
                            TaskFilter.PENDING -> task.parsedStatus == TaskStatus.PENDING ||
                                task.parsedStatus == TaskStatus.AWAITING_CONFIRMATION
                            TaskFilter.COMPLETED -> task.parsedStatus == TaskStatus.COMPLETED
                            TaskFilter.FAILED -> task.parsedStatus == TaskStatus.FAILED ||
                                task.parsedStatus == TaskStatus.CANCELLED
                        }
                    }

                    if (filtered.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.RocketLaunch,
                                    contentDescription = null,
                                    tint = ArcCyan.copy(alpha = 0.6f),
                                    modifier = Modifier.size(44.dp)
                                )
                                Text(
                                    text = "No agent tasks in this view yet",
                                    style = MaterialTheme.typography.titleMedium
                                )
                                Text(
                                    text = "Ask Jarvis in the Core tab to run battery checks, weather, YouTube searches, WhatsApp drafts, or daily plans.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(filtered, key = { it.id }) { task ->
                                AgentTaskTimelineCard(
                                    task = task,
                                    steps = localStepsByTask[task.id].orEmpty(),
                                    isActivePendingConfirmation = task.id == pendingPlanTaskId,
                                    onApprove = onApprovePending,
                                    onCancel = { onCancelTask(task.id) },
                                    onRetry = { onRetryTask(task.id) },
                                    onDelete = { onDeleteTask(task.id) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TaskMetricCard(
    label: String,
    count: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = CommandSurface,
        border = BorderStroke(1.dp, color.copy(alpha = 0.35f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(count.toString(), style = MaterialTheme.typography.titleLarge, color = color)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AgentTaskTimelineCard(
    task: AgentTask,
    steps: List<CachedStepEntity>,
    isActivePendingConfirmation: Boolean,
    onApprove: () -> Unit,
    onCancel: () -> Unit,
    onRetry: () -> Unit,
    onDelete: () -> Unit
) {
    val statusColor = when (task.parsedStatus) {
        TaskStatus.COMPLETED -> VerifiedEmerald
        TaskStatus.RUNNING -> ArcCyan
        TaskStatus.AWAITING_CONFIRMATION, TaskStatus.PENDING -> GateAmber
        TaskStatus.FAILED, TaskStatus.CANCELLED -> AlertCrimson
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_card_${task.id}"),
        shape = RoundedCornerShape(18.dp),
        color = CommandSurface,
        border = BorderStroke(1.dp, statusColor.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(task.title, style = MaterialTheme.typography.titleMedium)
                    Text(
                        text = "ID: ${task.id.take(14)} • ${task.completedStepsCount}/${task.stepsCount} verified",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StatusPill(label = task.parsedStatus.name.replace('_', ' '), color = statusColor)
            }

            LinearProgressIndicator(
                progress = { (task.progressPercent / 100f).coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp),
                color = statusColor,
                trackColor = CommandSurfaceHigh
            )

            // Execution Timeline Steps
            if (steps.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    steps.forEach { step ->
                        val stepState = StepStatus.safeParse(step.status)
                        val stepColor = when (stepState) {
                            StepStatus.VERIFIED -> VerifiedEmerald
                            StepStatus.RUNNING -> ArcCyan
                            StepStatus.FAILED, StepStatus.CANCELLED -> AlertCrimson
                            else -> GateAmber
                        }
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = CommandSurfaceHigh
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalAlignment = Alignment.Top
                            ) {
                                Icon(
                                    imageVector = when (stepState) {
                                        StepStatus.VERIFIED -> Icons.Filled.CheckCircle
                                        StepStatus.FAILED, StepStatus.CANCELLED -> Icons.Filled.Error
                                        else -> Icons.Filled.HourglassTop
                                    },
                                    contentDescription = stepState.name,
                                    tint = stepColor,
                                    modifier = Modifier.size(18.dp)
                                )
                                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(
                                        text = "${step.stepIndex + 1}. ${step.title}",
                                        style = MaterialTheme.typography.titleSmall
                                    )
                                    Text(
                                        text = "Tool: ${step.toolName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = SapphireBlue
                                    )
                                    step.actualResult?.let {
                                        Text(it, style = MaterialTheme.typography.bodySmall, color = VerifiedEmerald)
                                    }
                                    step.errorDetail?.let {
                                        Text(it, style = MaterialTheme.typography.bodySmall, color = AlertCrimson)
                                    }
                                    step.recoveryNote?.let {
                                        Text("Recovery: $it", style = MaterialTheme.typography.labelSmall, color = GateAmber)
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (task.stepsSummary.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    task.stepsSummary.forEach { line ->
                        Text(
                            text = "• $line",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            task.summary?.takeIf { it.isNotBlank() }?.let { summary ->
                Text(
                    text = summary,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            task.errorMessage?.takeIf { it.isNotBlank() }?.let { err ->
                Text(
                    text = err,
                    style = MaterialTheme.typography.bodySmall,
                    color = AlertCrimson
                )
            }

            // Task Action Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isActivePendingConfirmation && task.parsedStatus == TaskStatus.AWAITING_CONFIRMATION) {
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald, contentColor = MaterialTheme.colorScheme.onPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Approve")
                    }
                }

                if (task.parsedStatus == TaskStatus.RUNNING ||
                    task.parsedStatus == TaskStatus.PENDING ||
                    task.parsedStatus == TaskStatus.AWAITING_CONFIRMATION
                ) {
                    OutlinedButton(
                        onClick = onCancel,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("cancel_task_button_${task.id}")
                    ) {
                        Icon(Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.cancel_plan))
                    }
                }

                if (task.parsedStatus == TaskStatus.FAILED || task.parsedStatus == TaskStatus.CANCELLED) {
                    Button(
                        onClick = onRetry,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("retry_task_button_${task.id}")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(stringResource(R.string.retry_task))
                    }
                }

                Spacer(Modifier.weight(1f))

                IconButton(onClick = onDelete) {
                    Icon(
                        imageVector = Icons.Filled.DeleteOutline,
                        contentDescription = "Delete task record",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
