package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.data.model.AgentCoreState
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.GateAmber
import com.example.ui.theme.ReactorTeal
import com.example.ui.theme.SapphireBlue
import com.example.ui.theme.VerifiedEmerald
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun JarvisArcCore(
    coreState: AgentCoreState,
    amplitude: Float,
    isListening: Boolean,
    onMicToggle: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 154.dp
) {
    val infinite = rememberInfiniteTransition(label = "jarvis_core")
    val outerAngle by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = when (coreState) {
                    AgentCoreState.EXECUTING, AgentCoreState.THINKING -> 2600
                    AgentCoreState.LISTENING, AgentCoreState.SPEAKING -> 4200
                    else -> 9500
                },
                easing = LinearEasing
            )
        ),
        label = "outer_angle"
    )
    val innerAngle by infinite.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 5200, easing = LinearEasing)
        ),
        label = "inner_angle"
    )
    val pulse by infinite.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val primaryColor = when (coreState) {
        AgentCoreState.LISTENING -> ArcCyan
        AgentCoreState.THINKING -> SapphireBlue
        AgentCoreState.EXECUTING -> ReactorTeal
        AgentCoreState.AWAITING_CONFIRMATION -> GateAmber
        AgentCoreState.SPEAKING -> VerifiedEmerald
        AgentCoreState.ERROR -> AlertCrimson
        AgentCoreState.IDLE -> ArcCyan
    }

    val secondaryColor = when (coreState) {
        AgentCoreState.AWAITING_CONFIRMATION -> GateAmber.copy(alpha = 0.7f)
        AgentCoreState.ERROR -> AlertCrimson.copy(alpha = 0.7f)
        else -> SapphireBlue
    }

    val micDesc = if (isListening) {
        stringResource(R.string.mic_stop_listening)
    } else {
        stringResource(R.string.mic_start_listening)
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val radius = this.size.minDimension / 2f
            val center = Offset(this.size.width / 2f, this.size.height / 2f)
            val dynamicBoost = 1f + (amplitude.coerceIn(0f, 1f) * 0.14f)

            // Ambient radial reactor glow
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.28f),
                        secondaryColor.copy(alpha = 0.10f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * dynamicBoost
                ),
                radius = radius * dynamicBoost,
                center = center
            )

            // Outer orbital arc ring
            val outerR = radius * 0.90f
            drawArc(
                color = primaryColor.copy(alpha = 0.78f),
                startAngle = outerAngle,
                sweepAngle = 115f,
                useCenter = false,
                topLeft = Offset(center.x - outerR, center.y - outerR),
                size = Size(outerR * 2f, outerR * 2f),
                style = Stroke(width = 3.2.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = secondaryColor.copy(alpha = 0.65f),
                startAngle = outerAngle + 175f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(center.x - outerR, center.y - outerR),
                size = Size(outerR * 2f, outerR * 2f),
                style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round)
            )

            // Mid counter-rotating dashed telemetry ring
            val midR = radius * 0.74f
            for (seg in 0 until 6) {
                drawArc(
                    color = primaryColor.copy(alpha = 0.42f),
                    startAngle = innerAngle + (seg * 60f),
                    sweepAngle = 32f,
                    useCenter = false,
                    topLeft = Offset(center.x - midR, center.y - midR),
                    size = Size(midR * 2f, midR * 2f),
                    style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                )
            }

            // Pulsing inner halo
            drawCircle(
                color = primaryColor.copy(alpha = 0.24f),
                radius = radius * 0.56f * pulse * dynamicBoost,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )
        }

        // Large central interactive Microphone / Stop Listening control
        Surface(
            modifier = Modifier
                .size(72.dp)
                .minimumInteractiveComponentSize()
                .clip(CircleShape)
                .testTag("central_mic_button")
                .semantics { contentDescription = micDesc }
                .clickable(onClick = onMicToggle),
            shape = CircleShape,
            color = if (isListening) AlertCrimson.copy(alpha = 0.92f) else primaryColor.copy(alpha = 0.18f),
            border = BorderStroke(
                width = 2.dp,
                color = if (isListening) AlertCrimson else primaryColor
            )
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = when {
                        isListening -> Icons.Filled.Stop
                        coreState == AgentCoreState.SPEAKING -> Icons.Filled.GraphicEq
                        else -> Icons.Filled.Mic
                    },
                    contentDescription = micDesc,
                    tint = if (isListening) MaterialTheme.colorScheme.onError else primaryColor,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}

@Composable
fun VoiceWaveformBars(
    active: Boolean,
    amplitude: Float,
    color: Color = ArcCyan,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "waveform")
    val phase by infinite.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing)
        ),
        label = "wave_phase"
    )

    Row(
        modifier = modifier.height(28.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val barCount = 13
        for (i in 0 until barCount) {
            val centerWeight = 1f - (kotlin.math.abs(i - barCount / 2) / (barCount / 2f))
            val wave = if (active) {
                val osc = ((sin(phase + i * 0.7f) + 1f) / 2f)
                (0.22f + osc * (0.45f + amplitude.coerceIn(0f, 1f) * 0.55f) * (0.5f + centerWeight * 0.5f))
            } else {
                0.15f + centerWeight * 0.14f
            }
            val barHeight = (26.dp * wave.coerceIn(0.14f, 1f))
            Box(
                modifier = Modifier
                    .width(3.5.dp)
                    .height(barHeight)
                    .clip(RoundedCornerShape(4.dp))
                    .background(if (active) color else color.copy(alpha = 0.35f))
            )
        }
    }
}

@Composable
fun StatusPill(
    label: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = color.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, color.copy(alpha = 0.45f))
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = color,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}
