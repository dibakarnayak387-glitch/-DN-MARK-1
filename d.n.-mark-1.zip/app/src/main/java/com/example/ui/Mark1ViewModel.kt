package com.example.ui

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.agent.AgentEngineSnapshot
import com.example.agent.WorkAgentEngine
import com.example.ai.GeminiAgentBrain
import com.example.ai.LanguageDetector
import com.example.data.local.CachedMemoryEntity
import com.example.data.local.CachedStepEntity
import com.example.data.local.Mark1Database
import com.example.data.model.ActivePhotoDraft
import com.example.data.model.AgentCoreState
import com.example.data.model.AgentLanguage
import com.example.data.model.AgentTask
import com.example.data.model.ConversationMessage
import com.example.data.model.LanguagePreference
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.data.model.UiState
import com.example.data.model.UserReminder
import com.example.data.prefs.UserPreferences
import com.example.data.prefs.UserPreferencesRepository
import com.example.data.remote.Mark1FirestoreRepository
import com.example.tools.AgentTool
import com.example.tools.AndroidToolRegistry
import com.example.tools.ToolExecutionResult
import com.example.tools.ToolParams
import com.example.tools.ToolUiBridge
import com.example.voice.Mark1VoiceService
import com.example.voice.VoiceController
import com.example.voice.VoiceUiState
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

private const val TAG = "Mark1ViewModel"
private const val STOP_TIMEOUT_MS = 5000L

class Mark1ViewModel(
    private val appContext: Context,
    private val currentUserId: String,
    private val firestoreRepository: Mark1FirestoreRepository,
    private val database: Mark1Database,
    private val prefsRepository: UserPreferencesRepository
) : ViewModel() {

    private var uiBridge: ToolUiBridge? = null

    val toolRegistry: AndroidToolRegistry = AndroidToolRegistry(
        firestoreRepository = firestoreRepository,
        bridgeProvider = { uiBridge }
    )

    private val brain = GeminiAgentBrain(toolRegistry)

    private val workEngine = WorkAgentEngine(
        appContext = appContext,
        brain = brain,
        toolRegistry = toolRegistry,
        firestoreRepository = firestoreRepository,
        stepDao = database.stepDao(),
        taskPlanDao = database.taskPlanDao()
    )

    private val voiceController = VoiceController(
        appContext = appContext,
        onRecognizedCommand = { transcript ->
            sendUserCommand(transcript)
        }
    )

    // --- Two-Tier Firestore Flows with CancellationException Unwrapping ---

    val conversationsState: StateFlow<UiState<List<ConversationMessage>>> =
        firestoreRepository.observeConversations(currentUserId)
            .map<List<ConversationMessage>, UiState<List<ConversationMessage>>> { UiState.Success(it) }
            .catch { error -> handleStreamError(error, "conversations") { emit(it) } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val tasksState: StateFlow<UiState<List<AgentTask>>> =
        firestoreRepository.observeTasks(currentUserId)
            .map<List<AgentTask>, UiState<List<AgentTask>>> { UiState.Success(it) }
            .catch { error -> handleStreamError(error, "tasks") { emit(it) } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val memoriesState: StateFlow<UiState<List<MemoryItem>>> =
        firestoreRepository.observeMemories(currentUserId)
            .map<List<MemoryItem>, UiState<List<MemoryItem>>> { list ->
                syncMemoriesToRoomCache(list)
                UiState.Success(list)
            }
            .catch { error -> handleStreamError(error, "memories") { emit(it) } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val remindersState: StateFlow<UiState<List<UserReminder>>> =
        firestoreRepository.observeReminders(currentUserId)
            .map<List<UserReminder>, UiState<List<UserReminder>>> { UiState.Success(it) }
            .catch { error -> handleStreamError(error, "reminders") { emit(it) } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UiState.Loading)

    val localStepsByTask: StateFlow<Map<String, List<CachedStepEntity>>> =
        database.stepDao().observeStepsForUser(currentUserId)
            .map { steps -> steps.groupBy { it.taskId }.mapValues { (_, v) -> v.sortedBy { it.stepIndex } } }
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), emptyMap())

    val preferences: StateFlow<UserPreferences> =
        prefsRepository.preferencesFlow
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), UserPreferences())

    val engineState: StateFlow<AgentEngineSnapshot> = workEngine.state
    val voiceState: StateFlow<VoiceUiState> = voiceController.voiceState
    val isVoiceServiceRunning: StateFlow<Boolean> = Mark1VoiceService.isRunning

    private val _photoDraft = MutableStateFlow<ActivePhotoDraft?>(null)
    val photoDraft: StateFlow<ActivePhotoDraft?> = _photoDraft.asStateFlow()

    private val _toastBanner = MutableStateFlow<String?>(null)
    val toastBanner: StateFlow<String?> = _toastBanner.asStateFlow()

    private val _quickToolResults = MutableStateFlow<Map<String, String>>(emptyMap())
    val quickToolResults: StateFlow<Map<String, String>> = _quickToolResults.asStateFlow()

    val effectiveCoreState: StateFlow<AgentCoreState> =
        combine(engineState, voiceState) { engine, voice ->
            when {
                voice.isListening -> AgentCoreState.LISTENING
                voice.isSpeaking -> AgentCoreState.SPEAKING
                else -> engine.coreState
            }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(STOP_TIMEOUT_MS), AgentCoreState.IDLE)

    init {
        Mark1VoiceService.onStopRequestedCallback = {
            voiceController.stopListening()
        }
        viewModelScope.launch {
            preferences.collect { pref ->
                voiceController.updateSpeechRate(pref.speechRate)
            }
        }
    }

    fun attachUiBridge(bridge: ToolUiBridge?) {
        uiBridge = bridge
    }

    fun showBanner(message: String) {
        _toastBanner.value = message
    }

    fun dismissBanner() {
        _toastBanner.value = null
    }

    fun clearEngineError() = workEngine.clearError()
    fun dismissPermissionPrompt() = workEngine.dismissPermissionPrompt()
    fun dismissMemoryProposal() = workEngine.dismissMemoryProposal()

    // --- COMMAND SUBMISSION & WORK AGENT ACTIONS ---

    fun sendUserCommand(text: String) {
        val pref = preferences.value
        val history = (conversationsState.value as? UiState.Success)?.data.orEmpty()
        val memories = (memoriesState.value as? UiState.Success)?.data.orEmpty()
        val reminders = (remindersState.value as? UiState.Success)?.data.orEmpty()

        workEngine.submitCommand(
            scope = viewModelScope,
            userId = currentUserId,
            rawPrompt = text,
            languagePreference = pref.languagePreference,
            defaultCity = pref.defaultCity,
            recentHistory = history,
            memories = memories,
            reminders = reminders,
            onSpeakResponse = { reply, lang ->
                if (preferences.value.autoSpeakResponses) {
                    voiceController.speak(reply, lang)
                }
            }
        )
    }

    fun approvePendingPlan() {
        val reminders = (remindersState.value as? UiState.Success)?.data.orEmpty()
        workEngine.approvePendingPlan(
            scope = viewModelScope,
            defaultCity = preferences.value.defaultCity,
            openRemindersCount = reminders.count { !it.completed },
            onSpeakResponse = { reply, lang ->
                if (preferences.value.autoSpeakResponses) {
                    voiceController.speak(reply, lang)
                }
            }
        )
    }

    fun cancelTask(taskId: String) {
        workEngine.cancelTask(viewModelScope, currentUserId, taskId)
    }

    fun retryTask(taskId: String) {
        val reminders = (remindersState.value as? UiState.Success)?.data.orEmpty()
        workEngine.retryTask(
            scope = viewModelScope,
            userId = currentUserId,
            taskId = taskId,
            defaultCity = preferences.value.defaultCity,
            openRemindersCount = reminders.count { !it.completed },
            onSpeakResponse = { reply, lang ->
                if (preferences.value.autoSpeakResponses) {
                    voiceController.speak(reply, lang)
                }
            }
        )
    }

    fun deleteTask(taskId: String) {
        viewModelScope.launch {
            database.stepDao().deleteStepsForTask(taskId)
            database.taskPlanDao().deleteTaskPlan(taskId)
            firestoreRepository.deleteTask(currentUserId, taskId)
                .onFailure { showBanner(it.localizedMessage ?: "Failed to delete task") }
        }
    }

    // --- VOICE & FOREGROUND SERVICE ---

    fun toggleListening(hasMicPermission: Boolean, onRequestMicPermission: () -> Unit) {
        if (voiceState.value.isListening) {
            stopAllListening()
            return
        }
        if (!hasMicPermission) {
            onRequestMicPermission()
            return
        }
        val pref = preferences.value
        val activeLang = when (pref.languagePreference) {
            LanguagePreference.HINDI -> AgentLanguage.HINDI
            LanguagePreference.ODIA -> AgentLanguage.ODIA
            LanguagePreference.ENGLISH, LanguagePreference.AUTO -> AgentLanguage.ENGLISH
        }
        voiceController.startListening(
            language = activeLang,
            requireWakePhrase = pref.wakePhraseFilterEnabled,
            continuous = pref.continuousConversation
        )
    }

    fun stopAllListening() {
        voiceController.stopListening()
        if (Mark1VoiceService.isRunning.value) {
            Mark1VoiceService.stop(appContext)
        }
    }

    fun startForegroundVoiceSession(hasMicPermission: Boolean, onRequestMicPermission: () -> Unit) {
        if (!hasMicPermission) {
            onRequestMicPermission()
            return
        }
        Mark1VoiceService.start(appContext)
        val pref = preferences.value
        val lang = LanguageDetector.resolveLanguage("", pref.languagePreference)
        voiceController.startListening(
            language = lang,
            requireWakePhrase = pref.wakePhraseFilterEnabled,
            continuous = true
        )
        showBanner("Foreground voice session started. Tap Stop Listening anytime.")
    }

    fun speakText(text: String, language: AgentLanguage): Boolean =
        voiceController.speak(text, language)

    fun stopSpeaking() = voiceController.stopSpeaking()

    fun clearVoiceError() = voiceController.clearVoiceError()

    // --- PHOTO REVIEW & SHARE FLOW ---

    fun setCapturedPhoto(uriString: String, caption: String) {
        _photoDraft.value = ActivePhotoDraft(uriString = uriString, caption = caption)
    }

    fun clearPhotoDraft() {
        _photoDraft.value = null
    }

    // --- SMART MEMORY & REMINDERS ---

    fun approveMemoryProposal() {
        val proposal = engineState.value.pendingMemoryProposal ?: return
        workEngine.dismissMemoryProposal()
        addMemory(
            category = proposal.category,
            title = proposal.title,
            content = proposal.content,
            language = proposal.language,
            pinned = false
        )
    }

    fun addMemory(
        category: MemoryCategory,
        title: String,
        content: String,
        language: AgentLanguage,
        pinned: Boolean = false
    ) {
        viewModelScope.launch {
            firestoreRepository.createApprovedMemory(
                userId = currentUserId,
                category = category,
                title = title,
                content = content,
                language = language,
                pinned = pinned
            ).onSuccess {
                showBanner("Memory saved and synced.")
            }.onFailure {
                showBanner(it.localizedMessage ?: "Failed to save memory.")
            }
        }
    }

    fun updateMemory(
        memoryId: String,
        category: MemoryCategory,
        title: String,
        content: String,
        language: AgentLanguage,
        pinned: Boolean
    ) {
        viewModelScope.launch {
            firestoreRepository.updateMemory(
                userId = currentUserId,
                memoryId = memoryId,
                category = category,
                title = title,
                content = content,
                language = language,
                pinned = pinned
            ).onSuccess {
                showBanner("Memory updated.")
            }.onFailure {
                showBanner(it.localizedMessage ?: "Failed to update memory.")
            }
        }
    }

    fun deleteMemory(memoryId: String) {
        viewModelScope.launch {
            firestoreRepository.deleteMemory(currentUserId, memoryId)
                .onSuccess { showBanner("Memory deleted.") }
                .onFailure { showBanner(it.localizedMessage ?: "Failed to delete memory.") }
        }
    }

    fun addReminder(title: String, timeLabel: String, notes: String?) {
        viewModelScope.launch {
            firestoreRepository.createReminder(currentUserId, title, notes, timeLabel)
                .onSuccess { showBanner("Reminder saved.") }
                .onFailure { showBanner(it.localizedMessage ?: "Failed to save reminder.") }
        }
    }

    fun toggleReminder(reminderId: String, completed: Boolean) {
        viewModelScope.launch {
            firestoreRepository.toggleReminderCompleted(currentUserId, reminderId, completed)
                .onFailure { showBanner(it.localizedMessage ?: "Failed to update reminder.") }
        }
    }

    fun deleteReminder(reminderId: String) {
        viewModelScope.launch {
            firestoreRepository.deleteReminder(currentUserId, reminderId)
                .onFailure { showBanner(it.localizedMessage ?: "Failed to delete reminder.") }
        }
    }

    fun clearConversations() {
        viewModelScope.launch {
            firestoreRepository.clearConversationHistory(currentUserId)
                .onSuccess { showBanner("Conversation history cleared.") }
                .onFailure { showBanner(it.localizedMessage ?: "Failed to clear history.") }
        }
    }

    // --- QUICK TOOL DIAGNOSTICS ---

    fun runQuickToolCheck(tool: AgentTool) {
        viewModelScope.launch {
            val result = toolRegistry.executeTool(
                context = appContext,
                toolName = tool.name,
                params = ToolParams(
                    userId = currentUserId,
                    language = LanguageDetector.resolveLanguage("", preferences.value.languagePreference),
                    defaultCity = preferences.value.defaultCity,
                    title = "D.N. Mark 1 Diagnostic",
                    messageText = "D.N. Mark 1 tool check verified."
                )
            )
            val summary = when (result) {
                is ToolExecutionResult.Success -> "VERIFIED: ${result.summary}"
                is ToolExecutionResult.NeedsPermission -> "PERMISSION NEEDED: ${result.rationale}"
                is ToolExecutionResult.Failure -> "FAILED: ${result.reason}"
            }
            _quickToolResults.value = _quickToolResults.value + (tool.name to summary)
        }
    }

    // --- PREFERENCES ---

    fun setLanguagePreference(pref: LanguagePreference) {
        viewModelScope.launch { prefsRepository.setLanguagePreference(pref) }
    }

    fun setContinuousConversation(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setContinuousConversation(enabled) }
    }

    fun setWakePhraseFilter(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setWakePhraseFilter(enabled) }
    }

    fun setAutoSpeak(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setAutoSpeak(enabled) }
    }

    fun setSpeechRate(rate: Float) {
        viewModelScope.launch { prefsRepository.setSpeechRate(rate) }
    }

    fun setProactiveSuggestions(enabled: Boolean) {
        viewModelScope.launch { prefsRepository.setProactiveSuggestions(enabled) }
    }

    fun setDefaultCity(city: String) {
        viewModelScope.launch { prefsRepository.setDefaultCity(city) }
    }

    fun cleanupBeforeSignOut() {
        stopAllListening()
        voiceController.stopSpeaking()
    }

    override fun onCleared() {
        super.onCleared()
        voiceController.release()
    }

    private fun syncMemoriesToRoomCache(list: List<MemoryItem>) {
        viewModelScope.launch {
            try {
                val entities = list.map {
                    CachedMemoryEntity(
                        id = it.id,
                        userId = currentUserId,
                        category = it.category,
                        title = it.title,
                        content = it.content,
                        language = it.language,
                        pinned = it.pinned
                    )
                }
                database.memoryCacheDao().upsertAll(entities)
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun <T> handleStreamError(
        error: Throwable,
        streamName: String,
        emitState: suspend (UiState<T>) -> Unit
    ) {
        val firestoreError = generateSequence(error) { it.cause }
            .filterIsInstance<FirebaseFirestoreException>()
            .firstOrNull()
        if (firestoreError == null && error is CancellationException) throw error
        val rootError = firestoreError ?: error
        Log.w(TAG, "Error observing $streamName", rootError)
        emitState(UiState.Error(rootError.message ?: "Failed to sync $streamName"))
    }
}
