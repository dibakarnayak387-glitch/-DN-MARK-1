package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.data.model.AgentLanguage
import com.example.data.model.MemoryCategory
import com.example.data.model.MemoryItem
import com.example.data.model.UiState
import com.example.data.model.UserReminder
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.GateAmber
import com.example.ui.theme.VerifiedEmerald

@Composable
fun MemoryDashboardScreen(
    memoriesState: UiState<List<MemoryItem>>,
    remindersState: UiState<List<UserReminder>>,
    onAddMemory: (MemoryCategory, String, String, AgentLanguage, Boolean) -> Unit,
    onUpdateMemory: (String, MemoryCategory, String, String, AgentLanguage, Boolean) -> Unit,
    onDeleteMemory: (String) -> Unit,
    onAddReminder: (String, String, String?) -> Unit,
    onToggleReminder: (String, Boolean) -> Unit,
    onDeleteReminder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by rememberSaveable { mutableStateOf(0) } // 0 = Smart Memory, 1 = Day Plan & Reminders
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var selectedCategory by rememberSaveable { mutableStateOf<MemoryCategory?>(null) }

    var showMemoryDialog by remember { mutableStateOf(false) }
    var editingMemory by remember { mutableStateOf<MemoryItem?>(null) }
    var showReminderDialog by remember { mutableStateOf(false) }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    text = "SMART MEMORY & PLANNER",
                    style = MaterialTheme.typography.titleLarge,
                    color = ArcCyan
                )
                Text(
                    text = "User-approved context, saved instructions, and synced daily reminders",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(0, 2)
                    ) {
                        Text("Smart Memory")
                    }
                    SegmentedButton(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(1, 2)
                    ) {
                        Text("Day Plan & Reminders")
                    }
                }
            }

            if (activeTab == 0) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .testTag("memory_search_input"),
                    placeholder = { Text("Search saved memories & instructions…") },
                    leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = ArcCyan) },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp)
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedCategory == null,
                        onClick = { selectedCategory = null },
                        label = { Text("All") }
                    )
                    MemoryCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
                            label = { Text(cat.label) }
                        )
                    }
                }

                when (memoriesState) {
                    is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = ArcCyan)
                    }

                    is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(memoriesState.message, color = AlertCrimson)
                    }

                    is UiState.Success -> {
                        val filtered = memoriesState.data.filter { item ->
                            val matchesCat = selectedCategory == null || item.parsedCategory == selectedCategory
                            val q = searchQuery.trim()
                            val matchesText = q.isEmpty() ||
                                item.title.contains(q, ignoreCase = true) ||
                                item.content.contains(q, ignoreCase = true)
                            matchesCat && matchesText
                        }

                        if (filtered.isEmpty()) {
                            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Icon(Icons.Filled.Psychology, contentDescription = null, tint = ArcCyan.copy(alpha = 0.6f), modifier = Modifier.size(44.dp))
                                    Text("No approved memories yet", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        "Tap + to add preferences or tell Jarvis to remember something. D.N. Mark 1 always asks consent before saving personal data.",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp, top = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(filtered, key = { it.id }) { item ->
                                    MemoryCard(
                                        item = item,
                                        onTogglePin = {
                                            onUpdateMemory(
                                                item.id,
                                                item.parsedCategory,
                                                item.title,
                                                item.content,
                                                item.parsedLanguage,
                                                !item.pinned
                                            )
                                        },
                                        onEdit = {
                                            editingMemory = item
                                            showMemoryDialog = true
                                        },
                                        onDelete = { onDeleteMemory(item.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            } else {
                when (remindersState) {
                    is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = ArcCyan)
                    }

                    is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(remindersState.message, color = AlertCrimson)
                    }

                    is UiState.Success -> {
                        val reminders = remindersState.data
                        if (reminders.isEmpty()) {
                            Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    "No reminders or day-plan items yet. Tap + or ask Jarvis \"Help me organize my day\".",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 88.dp, top = 4.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                items(reminders, key = { it.id }) { rem ->
                                    ReminderCard(
                                        reminder = rem,
                                        onToggle = { onToggleReminder(rem.id, !rem.completed) },
                                        onDelete = { onDeleteReminder(rem.id) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                if (activeTab == 0) {
                    editingMemory = null
                    showMemoryDialog = true
                } else {
                    showReminderDialog = true
                }
            },
            containerColor = ArcCyan,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("memory_add_fab")
        ) {
            Icon(Icons.Filled.Add, contentDescription = if (activeTab == 0) "Add Memory" else "Add Reminder")
        }
    }

    if (showMemoryDialog) {
        MemoryEditorDialog(
            initial = editingMemory,
            onDismiss = { showMemoryDialog = false },
            onSave = { cat, title, content, lang, pinned ->
                val existing = editingMemory
                if (existing == null) {
                    onAddMemory(cat, title, content, lang, pinned)
                } else {
                    onUpdateMemory(existing.id, cat, title, content, lang, pinned)
                }
                showMemoryDialog = false
            }
        )
    }

    if (showReminderDialog) {
        ReminderEditorDialog(
            onDismiss = { showReminderDialog = false },
            onSave = { title, timeLabel, notes ->
                onAddReminder(title, timeLabel, notes)
                showReminderDialog = false
            }
        )
    }
}

@Composable
private fun MemoryCard(
    item: MemoryItem,
    onTogglePin: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = CommandSurface,
        border = BorderStroke(1.dp, if (item.pinned) ArcCyan else MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                StatusPill(label = item.parsedCategory.label.uppercase(), color = if (item.pinned) ArcCyan else GateAmber)
                Row {
                    IconButton(onClick = onTogglePin) {
                        Icon(
                            imageVector = if (item.pinned) Icons.Filled.PushPin else Icons.Outlined.PushPin,
                            contentDescription = "Pin memory",
                            tint = if (item.pinned) ArcCyan else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit memory", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete memory", tint = AlertCrimson)
                    }
                }
            }
            Text(item.title, style = MaterialTheme.typography.titleMedium)
            Text(item.content, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ReminderCard(
    reminder: UserReminder,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = CommandSurface,
        border = BorderStroke(1.dp, if (reminder.completed) VerifiedEmerald.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(onClick = onToggle) {
                Icon(
                    imageVector = if (reminder.completed) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                    contentDescription = "Toggle reminder",
                    tint = if (reminder.completed) VerifiedEmerald else ArcCyan
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = reminder.title,
                    style = MaterialTheme.typography.titleSmall,
                    textDecoration = if (reminder.completed) TextDecoration.LineThrough else TextDecoration.None
                )
                Text(
                    text = reminder.scheduledTimeLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = ArcCyan
                )
                reminder.notes?.takeIf { it.isNotBlank() }?.let {
                    Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Filled.DeleteOutline, contentDescription = "Delete reminder", tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun MemoryEditorDialog(
    initial: MemoryItem?,
    onDismiss: () -> Unit,
    onSave: (MemoryCategory, String, String, AgentLanguage, Boolean) -> Unit
) {
    var title by remember { mutableStateOf(initial?.title.orEmpty()) }
    var content by remember { mutableStateOf(initial?.content.orEmpty()) }
    var category by remember { mutableStateOf(initial?.parsedCategory ?: MemoryCategory.PREFERENCE) }
    var pinned by remember { mutableStateOf(initial?.pinned ?: false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Save Approved Memory" else "Edit Memory") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    MemoryCategory.entries.forEach { cat ->
                        FilterChip(
                            selected = category == cat,
                            onClick = { category = cat },
                            label = { Text(cat.label) }
                        )
                    }
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Details / Standing Instruction") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = pinned, onCheckedChange = { pinned = it })
                    Spacer(Modifier.width(4.dp))
                    Text("Pin to top of Gemini context", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && content.isNotBlank()) {
                        onSave(category, title, content, initial?.parsedLanguage ?: AgentLanguage.ENGLISH, pinned)
                    }
                },
                enabled = title.isNotBlank() && content.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun ReminderEditorDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String?) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var timeLabel by remember { mutableStateOf("Today") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Reminder / Day Plan Item") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = timeLabel,
                    onValueChange = { timeLabel = it },
                    label = { Text("Schedule (e.g., Today 6:00 PM)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onSave(title, timeLabel.ifBlank { "Today" }, notes.takeIf { it.isNotBlank() })
                    }
                },
                enabled = title.isNotBlank()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
