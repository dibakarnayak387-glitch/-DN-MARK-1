package com.example.ui.screens

import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdded
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.R
import com.example.agent.AgentEngineSnapshot
import com.example.data.model.ActivePhotoDraft
import com.example.data.model.AgentCoreState
import com.example.data.model.AgentLanguage
import com.example.data.model.ConversationMessage
import com.example.data.model.LanguagePreference
import com.example.data.model.MemoryProposal
import com.example.data.model.MessageRole
import com.example.data.model.PendingTaskPlan
import com.example.data.model.UiState
import com.example.data.prefs.UserPreferences
import com.example.ui.components.JarvisArcCore
import com.example.ui.components.StatusPill
import com.example.ui.components.VoiceWaveformBars
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceHigh
import com.example.ui.theme.GateAmber
import com.example.ui.theme.SapphireBlue
import com.example.ui.theme.VerifiedEmerald
import com.example.voice.VoiceUiState

@Composable
fun CommandCoreScreen(
    conversationsState: UiState<List<ConversationMessage>>,
    coreState: AgentCoreState,
    engineState: AgentEngineSnapshot,
    voiceState: VoiceUiState,
    isVoiceServiceRunning: Boolean,
    preferences: UserPreferences,
    photoDraft: ActivePhotoDraft?,
    openRemindersCount: Int,
    onSendCommand: (String) -> Unit,
    onMicToggle: () -> Unit,
    onStopListening: () -> Unit,
    onStopSpeaking: () -> Unit,
    onSpeakMessage: (String, AgentLanguage) -> Unit,
    onLanguageChange: (LanguagePreference) -> Unit,
    onApprovePlan: () -> Unit,
    onCancelTask: (String) -> Unit,
    onApproveMemory: () -> Unit,
    onDismissMemory: () -> Unit,
    onRequestPermission: (String) -> Unit,
    onDismissPermission: () -> Unit,
    onPickPhoto: () -> Unit,
    onSharePhotoDraft: (ActivePhotoDraft) -> Unit,
    onDismissPhotoDraft: () -> Unit,
    onClearError: () -> Unit,
    onClearVoiceError: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()
    val messages = (conversationsState as? UiState.Success)?.data.orEmpty()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.lastIndex)
        }
    }

    Box(
        modifier = modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            // Top HUD Header: Brand, Language pills, Active Listening Stop button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "D.N. MARK 1",
                        style = MaterialTheme.typography.titleLarge,
                        color = ArcCyan
                    )
                    Text(
                        text = if (openRemindersCount > 0) {
                            "Mobile Jarvis • $openRemindersCount open task(s)"
                        } else {
                            "Mobile Work Agent • Gemini Core"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (voiceState.isListening || isVoiceServiceRunning) {
                        Button(
                            onClick = onStopListening,
                            colors = ButtonDefaults.buttonColors(containerColor = AlertCrimson),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("stop_listening_header_button")
                        ) {
                            Icon(Icons.Filled.StopCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Stop", style = MaterialTheme.typography.labelLarge)
                        }
                    } else if (voiceState.isSpeaking) {
                        OutlinedButton(
                            onClick = onStopSpeaking,
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("stop_speaking_button")
                        ) {
                            Icon(Icons.Filled.StopCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Mute", style = MaterialTheme.typography.labelLarge)
                        }
                    } else {
                        StatusPill(
                            label = coreState.name.replace('_', ' '),
                            color = when (coreState) {
                                AgentCoreState.EXECUTING -> VerifiedEmerald
                                AgentCoreState.AWAITING_CONFIRMATION -> GateAmber
                                AgentCoreState.ERROR -> AlertCrimson
                                else -> ArcCyan
                            }
                        )
                    }
                }
            }

            // Language quick-selector strip (Auto / EN / हिन्दी / ଓଡ଼ିଆ)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LanguagePreference.entries.forEach { pref ->
                    FilterChip(
                        selected = preferences.languagePreference == pref,
                        onClick = { onLanguageChange(pref) },
                        label = { Text(pref.label, style = MaterialTheme.typography.labelMedium) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = ArcCyan.copy(alpha = 0.2f),
                            selectedLabelColor = ArcCyan
                        ),
                        modifier = Modifier.testTag("lang_chip_${pref.code}")
                    )
                }
            }

            // Central AI Core & Live Waveform Panel
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                shape = RoundedCornerShape(22.dp),
                color = CommandSurface.copy(alpha = 0.90f),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    JarvisArcCore(
                        coreState = coreState,
                        amplitude = voiceState.rmsAmplitude,
                        isListening = voiceState.isListening,
                        onMicToggle = onMicToggle,
                        size = 112.dp
                    )

                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = when {
                                voiceState.isListening -> "Listening… Say \"Jarvis\" or command"
                                voiceState.isSpeaking -> "Speaking verified response…"
                                else -> engineState.statusDetail
                            },
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )

                        VoiceWaveformBars(
                            active = voiceState.isListening || voiceState.isSpeaking || coreState == AgentCoreState.EXECUTING,
                            amplitude = if (voiceState.isListening) voiceState.rmsAmplitude else 0.45f,
                            color = when {
                                voiceState.isListening -> ArcCyan
                                voiceState.isSpeaking -> VerifiedEmerald
                                coreState == AgentCoreState.EXECUTING -> SapphireBlue
                                else -> ArcCyan
                            }
                        )

                        if (voiceState.partialTranscript.isNotBlank()) {
                            Text(
                                text = "“${voiceState.partialTranscript}”",
                                style = MaterialTheme.typography.bodySmall,
                                color = ArcCyan,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                        } else if (voiceState.ttsLanguageNote != null) {
                            Text(
                                text = voiceState.ttsLanguageNote,
                                style = MaterialTheme.typography.bodySmall,
                                color = GateAmber,
                                maxLines = 2
                            )
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Hearing,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(14.dp)
                                )
                                Text(
                                    text = if (preferences.wakePhraseFilterEnabled) {
                                        "Wake filter: \"Jarvis\" ON"
                                    } else {
                                        "Tap core mic to speak"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            // Inline Error & Voice Error Alerts
            AnimatedVisibility(visible = engineState.lastError != null || voiceState.voiceError != null) {
                val msg = engineState.lastError ?: voiceState.voiceError.orEmpty()
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.errorContainer,
                    border = BorderStroke(1.dp, AlertCrimson)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Filled.ErrorOutline, contentDescription = null, tint = AlertCrimson, modifier = Modifier.size(18.dp))
                        Text(
                            text = msg,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = {
                            onClearError()
                            onClearVoiceError()
                        }) {
                            Icon(Icons.Filled.Close, contentDescription = "Dismiss error", tint = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
            }

            // Inline Runtime Permission Request Card
            AnimatedVisibility(visible = engineState.permissionRequestNeeded != null) {
                val perm = engineState.permissionRequestNeeded ?: return@AnimatedVisibility
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = GateAmber.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, GateAmber)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Filled.Shield, contentDescription = null, tint = GateAmber)
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Permission Required", style = MaterialTheme.typography.titleSmall, color = GateAmber)
                            Text(
                                text = engineState.permissionRationale ?: perm,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Button(
                            onClick = {
                                onDismissPermission()
                                onRequestPermission(perm)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GateAmber, contentColor = MaterialTheme.colorScheme.onPrimary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text("Allow")
                        }
                    }
                }
            }

            // Inline Action Plan Confirmation Gate Card
            AnimatedVisibility(visible = engineState.pendingPlan != null) {
                engineState.pendingPlan?.let { plan ->
                    PlanConfirmationCard(
                        plan = plan,
                        onApprove = onApprovePlan,
                        onCancel = { onCancelTask(plan.taskId) },
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }

            // Inline Smart Memory Consent Card
            AnimatedVisibility(visible = engineState.pendingMemoryProposal != null) {
                engineState.pendingMemoryProposal?.let { proposal ->
                    MemoryConsentCard(
                        proposal = proposal,
                        onApprove = onApproveMemory,
                        onDismiss = onDismissMemory,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }

            // Inline Captured Photo Review & Share Card
            AnimatedVisibility(visible = photoDraft != null) {
                photoDraft?.let { draft ->
                    PhotoReviewShareCard(
                        draft = draft,
                        onShare = { onSharePhotoDraft(draft) },
                        onDismiss = onDismissPhotoDraft,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
            }

            // Conversation Feed or First-Launch Quick Action Mission Grid
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        EmptyCommandWelcomeCard(
                            onQuickPrompt = onSendCommand
                        )
                    }
                } else {
                    items(messages, key = { it.id.ifBlank { it.hashCode().toString() } }) { msg ->
                        ChatBubble(
                            message = msg,
                            onSpeak = { onSpeakMessage(msg.text, msg.parsedLanguage) }
                        )
                    }
                }
            }

            // Proactive Next-Step Suggestions Strip
            val suggestions = if (preferences.proactiveSuggestionsEnabled) {
                engineState.proactiveSuggestions.ifEmpty {
                    listOf(
                        "Check battery, weather & YouTube Iron Man tech",
                        "Prepare WhatsApp for Divakar Nayak: I will call later",
                        "Help me organize my day",
                        "Open camera to share a photo"
                    )
                }
            } else emptyList()

            if (suggestions.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    suggestions.forEachIndexed { idx, prompt ->
                        SuggestionChip(
                            onClick = { onSendCommand(prompt) },
                            icon = {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = null,
                                    tint = ArcCyan,
                                    modifier = Modifier.size(15.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = prompt,
                                    style = MaterialTheme.typography.bodySmall,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            modifier = Modifier.testTag("suggestion_chip_$idx")
                        )
                    }
                }
            }

            // Command Composer Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                IconButton(
                    onClick = onPickPhoto,
                    modifier = Modifier.testTag("photo_picker_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.AddPhotoAlternate,
                        contentDescription = "Select photo to share",
                        tint = ArcCyan
                    )
                }

                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("command_text_input"),
                    placeholder = {
                        Text(
                            text = stringResource(R.string.command_input_hint),
                            style = MaterialTheme.typography.bodyMedium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    shape = RoundedCornerShape(18.dp),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ArcCyan,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedContainerColor = CommandSurface,
                        unfocusedContainerColor = CommandSurface
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(
                        onSend = {
                            if (inputText.isNotBlank()) {
                                onSendCommand(inputText)
                                inputText = ""
                            }
                        }
                    )
                )

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (inputText.isNotBlank()) ArcCyan else CommandSurfaceHigh
                ) {
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                onSendCommand(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier.testTag("send_command_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = stringResource(R.string.send_command),
                            tint = if (inputText.isNotBlank()) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PlanConfirmationCard(
    plan: PendingTaskPlan,
    onApprove: () -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = CommandSurfaceHigh,
        border = BorderStroke(1.5.dp, GateAmber)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "CONFIRM EXECUTION PLAN",
                    style = MaterialTheme.typography.labelMedium,
                    color = GateAmber
                )
                StatusPill(label = "${plan.steps.size} STEP(S)", color = GateAmber)
            }
            Text(
                text = plan.title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurface
            )
            plan.steps.forEachIndexed { idx, step ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = "${idx + 1}.",
                        style = MaterialTheme.typography.labelMedium,
                        color = ArcCyan
                    )
                    Column {
                        Text(
                            text = "${step.title} (${step.toolName})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        val detail = listOfNotNull(
                            step.recipient?.let { "To: $it" },
                            step.messageText?.let { "“$it”" },
                            step.query?.let { "Query: $it" },
                            step.timeLabel?.let { "When: $it" }
                        ).joinToString(" • ")
                        if (detail.isNotEmpty()) {
                            Text(
                                text = detail,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = onCancel,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("cancel_plan_button")
                ) {
                    Icon(Icons.Filled.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.cancel_plan))
                }
                Button(
                    onClick = onApprove,
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("approve_plan_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = VerifiedEmerald, contentColor = MaterialTheme.colorScheme.onPrimary)
                ) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.approve_plan))
                }
            }
        }
    }
}

@Composable
private fun MemoryConsentCard(
    proposal: MemoryProposal,
    onApprove: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = CommandSurfaceHigh,
        border = BorderStroke(1.dp, ArcCyan)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Filled.BookmarkAdded, contentDescription = null, tint = ArcCyan, modifier = Modifier.size(18.dp))
                Text(
                    text = "SAVE TO SMART MEMORY? (${proposal.category.label})",
                    style = MaterialTheme.typography.labelMedium,
                    color = ArcCyan
                )
            }
            Text(proposal.title, style = MaterialTheme.typography.titleSmall)
            Text(
                proposal.content,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                    Text(stringResource(R.string.decline_memory))
                }
                Button(
                    onClick = onApprove,
                    modifier = Modifier
                        .weight(1.3f)
                        .testTag("approve_memory_button")
                ) {
                    Icon(Icons.Filled.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(stringResource(R.string.save_memory_confirm))
                }
            }
        }
    }
}

@Composable
private fun PhotoReviewShareCard(
    draft: ActivePhotoDraft,
    onShare: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = CommandSurfaceHigh,
        border = BorderStroke(1.5.dp, ArcCyan)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            AsyncImage(
                model = Uri.parse(draft.uriString),
                contentDescription = "Captured photo preview",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(74.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(CommandSurface)
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Photo Ready to Share", style = MaterialTheme.typography.titleSmall, color = ArcCyan)
                Text(
                    draft.caption,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = onShare,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("share_photo_button")
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Share via Android")
                    }
                    OutlinedButton(
                        onClick = onDismiss,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text("Discard")
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(
    message: ConversationMessage,
    onSpeak: () -> Unit
) {
    val isUser = message.parsedRole == MessageRole.USER
    val isSystem = message.parsedRole == MessageRole.SYSTEM

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            modifier = Modifier.widthIn(max = 520.dp),
            shape = RoundedCornerShape(
                topStart = 18.dp,
                topEnd = 18.dp,
                bottomStart = if (isUser) 18.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 18.dp
            ),
            color = when {
                isUser -> SapphireBlue.copy(alpha = 0.28f)
                isSystem -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.7f)
                else -> CommandSurface
            },
            border = BorderStroke(
                width = 1.dp,
                color = when {
                    isUser -> SapphireBlue.copy(alpha = 0.6f)
                    isSystem -> AlertCrimson
                    else -> MaterialTheme.colorScheme.outline
                }
            )
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = when {
                            isUser -> "YOU • ${message.parsedLanguage.code.uppercase()}"
                            isSystem -> "SYSTEM"
                            else -> "D.N. MARK 1 • ${message.parsedLanguage.code.uppercase()}"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isUser) ArcCyan else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (!isUser && !isSystem) {
                        IconButton(
                            onClick = onSpeak,
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Read response aloud",
                                tint = ArcCyan,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
private fun EmptyCommandWelcomeCard(
    onQuickPrompt: (String) -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = CommandSurface.copy(alpha = 0.85f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "Ready for Multi-Step Missions",
                style = MaterialTheme.typography.titleMedium,
                color = ArcCyan
            )
            Text(
                text = "Speak or type in English, हिन्दी, or ଓଡ଼ିଆ. D.N. Mark 1 plans ordered steps, asks approval for sensitive actions, verifies results, and syncs approved memory.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            val missions = listOf(
                "Jarvis, check my battery, tell me the weather and search Iron Man technology on YouTube.",
                "Jarvis, prepare a WhatsApp message for Divakar Nayak saying I will call later.",
                "जार्विस, मेरी बैटरी और मौसम बताओ।",
                "ଜାର୍ଭିସ୍, ମୋର ବ୍ୟାଟେରୀ ଏବଂ ପାଣିପାଗ କୁହ।"
            )
            missions.forEach { mission ->
                OutlinedButton(
                    onClick = { onQuickPrompt(mission) },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = mission,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}
