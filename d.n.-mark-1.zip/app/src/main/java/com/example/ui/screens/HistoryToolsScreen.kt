package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.ConversationMessage
import com.example.data.model.UiState
import com.example.tools.AgentTool
import com.example.ui.components.StatusPill
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.CommandSurfaceHigh
import com.example.ui.theme.GateAmber
import com.example.ui.theme.VerifiedEmerald

@Composable
fun HistoryToolsScreen(
    tools: List<AgentTool>,
    quickToolResults: Map<String, String>,
    conversationsState: UiState<List<ConversationMessage>>,
    onRunToolDiagnostic: (AgentTool) -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    var activeTab by rememberSaveable { mutableStateOf(0) } // 0 = Android Tool Registry, 1 = Conversation History
    val safeDiagnosticTools = setOf("check_battery", "check_charging_status", "get_device_info", "get_weather", "send_notification")

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text(
                    text = "TOOLS & AUDIT HISTORY",
                    style = MaterialTheme.typography.titleLarge,
                    color = ArcCyan
                )
                Text(
                    text = "${tools.size} controlled Android tools • Zero arbitrary shell execution",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = activeTab == 0,
                        onClick = { activeTab = 0 },
                        shape = SegmentedButtonDefaults.itemShape(0, 2)
                    ) {
                        Text("Tool Registry (${tools.size})")
                    }
                    SegmentedButton(
                        selected = activeTab == 1,
                        onClick = { activeTab = 1 },
                        shape = SegmentedButtonDefaults.itemShape(1, 2)
                    ) {
                        Text("History Log")
                    }
                }
            }

            if (activeTab == 0) {
                LazyColumn(
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(tools, key = { it.name }) { tool ->
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            color = CommandSurface,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(
                                modifier = Modifier.padding(14.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Filled.Build, contentDescription = null, tint = ArcCyan, modifier = Modifier.size(18.dp))
                                        Column {
                                            Text(tool.displayName, style = MaterialTheme.typography.titleSmall)
                                            Text(tool.name, style = MaterialTheme.typography.labelSmall, color = ArcCyan)
                                        }
                                    }
                                    StatusPill(
                                        label = if (tool.requiresConfirmation) "CONFIRM GATE" else "AUTO-SAFE",
                                        color = if (tool.requiresConfirmation) GateAmber else VerifiedEmerald
                                    )
                                }

                                Text(
                                    text = tool.description,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )

                                if (tool.requiredPermissions.isNotEmpty()) {
                                    Text(
                                        text = "Permissions: ${tool.requiredPermissions.joinToString { it.substringAfterLast('.') }}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = GateAmber
                                    )
                                }

                                quickToolResults[tool.name]?.let { resultText ->
                                    Surface(
                                        shape = RoundedCornerShape(10.dp),
                                        color = CommandSurfaceHigh
                                    ) {
                                        Text(
                                            text = resultText,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = VerifiedEmerald,
                                            modifier = Modifier.padding(10.dp)
                                        )
                                    }
                                }

                                if (tool.name in safeDiagnosticTools) {
                                    Button(
                                        onClick = { onRunToolDiagnostic(tool) },
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.testTag("test_tool_${tool.name}")
                                    ) {
                                        Icon(Icons.Filled.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Verify Live")
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                val messages = (conversationsState as? UiState.Success)?.data.orEmpty().reversed()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (messages.isNotEmpty()) {
                        OutlinedButton(onClick = onClearHistory) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Clear Chat History")
                        }
                    }
                }
                if (messages.isEmpty()) {
                    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No conversation history recorded yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                } else {
                    LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(messages, key = { it.id.ifBlank { it.hashCode().toString() } }) { msg ->
                            Surface(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                color = CommandSurface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Text(
                                        text = "${msg.role} • ${msg.language.uppercase()}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = ArcCyan
                                    )
                                    Text(msg.text, style = MaterialTheme.typography.bodySmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
