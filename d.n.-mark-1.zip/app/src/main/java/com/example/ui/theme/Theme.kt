package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val Mark1DarkColorScheme = darkColorScheme(
    primary = ArcCyan,
    onPrimary = OnArcCyan,
    primaryContainer = ArcCyanDim,
    onPrimaryContainer = ArcCyanSoft,
    secondary = SapphireBlue,
    onSecondary = IceWhite,
    secondaryContainer = SapphireContainer,
    onSecondaryContainer = OnSapphireContainer,
    tertiary = ReactorTeal,
    onTertiary = OnArcCyan,
    tertiaryContainer = ReactorTealContainer,
    onTertiaryContainer = IceWhite,
    background = ObsidianVoid,
    onBackground = IceWhite,
    surface = DeepSpace,
    onSurface = IceWhite,
    surfaceVariant = CommandSurface,
    onSurfaceVariant = FrostSlate,
    surfaceContainerLowest = ObsidianVoid,
    surfaceContainerLow = DeepSpace,
    surfaceContainer = CommandSurface,
    surfaceContainerHigh = CommandSurfaceHigh,
    surfaceContainerHighest = CommandSurfaceHighest,
    outline = CommandOutline,
    outlineVariant = CommandOutlineSubtle,
    error = AlertCrimson,
    onError = ObsidianVoid,
    errorContainer = AlertCrimsonContainer,
    onErrorContainer = IceWhite
)

private val Mark1Shapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun Mark1Theme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = Mark1DarkColorScheme,
        typography = Mark1Typography,
        shapes = Mark1Shapes,
        content = content
    )
}
