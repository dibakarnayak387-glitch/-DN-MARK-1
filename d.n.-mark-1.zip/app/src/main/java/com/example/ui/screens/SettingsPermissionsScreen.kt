package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.prefs.UserPreferences
import com.example.ui.components.StatusPill
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.ArcCyan
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.GateAmber
import com.example.ui.theme.VerifiedEmerald
import java.util.Locale

@Composable
fun SettingsPermissionsScreen(
    userEmail: String?,
    userDisplayName: String?,
    preferences: UserPreferences,
    isVoiceServiceRunning: Boolean,
    permissionRefreshKey: Int,
    onRequestPermission: (String) -> Unit,
    onStartVoiceService: () -> Unit,
    onStopVoiceService: () -> Unit,
    onSetContinuous: (Boolean) -> Unit,
    onSetWakePhrase: (Boolean) -> Unit,
    onSetAutoSpeak: (Boolean) -> Unit,
    onSetSpeechRate: (Float) -> Unit,
    onSetProactive: (Boolean) -> Unit,
    onSetDefaultCity: (String) -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var cityInput by remember(preferences.defaultCity) { mutableStateOf(preferences.defaultCity) }

    fun isGranted(perm: String): Boolean =
        ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED

    val micGranted = remember(permissionRefreshKey) { isGranted(Manifest.permission.RECORD_AUDIO) }
    val cameraGranted = remember(permissionRefreshKey) { isGranted(Manifest.permission.CAMERA) }
    val locationGranted = remember(permissionRefreshKey) { isGranted(Manifest.permission.ACCESS_COARSE_LOCATION) }
    val notifGranted = remember(permissionRefreshKey) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            isGranted(Manifest.permission.POST_NOTIFICATIONS)
        } else true
    }

    Box(modifier = modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .widthIn(max = 760.dp)
                .fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("CONTROL & PERMISSIONS", style = MaterialTheme.typography.titleLarge, color = ArcCyan)
                Text(
                    "Runtime Android permissions, compliant foreground voice session & security settings",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // 1. Permission Dashboard
            item {
                ControlSectionCard(title = "Android Permission Dashboard") {
                    PermissionRow(
                        icon = Icons.Filled.Mic,
                        title = "Microphone (RECORD_AUDIO)",
                        purpose = "Voice commands, speech-to-text, and active Jarvis session",
                        granted = micGranted,
                        onGrant = { onRequestPermission(Manifest.permission.RECORD_AUDIO) }
                    )
                    PermissionRow(
                        icon = Icons.Filled.LocationOn,
                        title = "Coarse Location",
                        purpose = "Local weather conditions (city fallback works without it)",
                        granted = locationGranted,
                        onGrant = { onRequestPermission(Manifest.permission.ACCESS_COARSE_LOCATION) }
                    )
                    PermissionRow(
                        icon = Icons.Filled.CameraAlt,
                        title = "Camera",
                        purpose = "Capture & review photos before sharing via Android Share Sheet",
                        granted = cameraGranted,
                        onGrant = { onRequestPermission(Manifest.permission.CAMERA) }
                    )
                    PermissionRow(
                        icon = Icons.Filled.Notifications,
                        title = "Notifications",
                        purpose = "Foreground voice session indicator and reminder alerts",
                        granted = notifGranted,
                        onGrant = {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                onRequestPermission(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        }
                    )
                    OutlinedButton(
                        onClick = {
                            val intent = Intent(
                                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.fromParts("package", context.packageName, null)
                            )
                            context.startActivity(intent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Open Android App Permission Settings")
                    }
                }
            }

            // 2. Voice & Foreground Service Controls + Transparent OS Restrictions
            item {
                ControlSectionCard(title = "Voice Engine & Wake Phrase (\"Jarvis\")") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (isVoiceServiceRunning) {
                            Button(
                                onClick = onStopVoiceService,
                                colors = ButtonDefaults.buttonColors(containerColor = AlertCrimson),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("stop_voice_service_button")
                            ) {
                                Icon(Icons.Filled.StopCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Stop Foreground Voice Session")
                            }
                        } else {
                            Button(
                                onClick = onStartVoiceService,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("start_voice_service_button")
                            ) {
                                Icon(Icons.Filled.Mic, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Start Foreground Voice Session")
                            }
                        }
                    }

                    // Transparent Android Restriction Disclosure
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GateAmber.copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, GateAmber.copy(alpha = 0.45f))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(Icons.Filled.Info, contentDescription = null, tint = GateAmber, modifier = Modifier.size(18.dp))
                            Text(
                                text = "Android OS Restriction: Third-party apps cannot run silent, always-on hotword detection with the screen off (reserved for OEM/system VoiceInteractionService DSPs). D.N. Mark 1 uses an Android 14+ compliant microphone foreground service with a visible ongoing notification and one-tap Stop Listening button whenever active listening is turned on.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    ToggleSettingRow(
                        title = "Require \"Jarvis\" Wake Phrase",
                        subtitle = "Ignore ambient speech unless \"Jarvis\" / \"जार्विस\" / \"ଜାର୍ଭିସ୍\" is spoken",
                        checked = preferences.wakePhraseFilterEnabled,
                        onCheckedChange = onSetWakePhrase
                    )
                    ToggleSettingRow(
                        title = "Continuous Conversation Mode",
                        subtitle = "Automatically resume listening after Jarvis finishes speaking",
                        checked = preferences.continuousConversation,
                        onCheckedChange = onSetContinuous
                    )
                    ToggleSettingRow(
                        title = "Auto-Speak Verified Replies (TTS)",
                        subtitle = "Read replies aloud in English, Hindi, or Odia",
                        checked = preferences.autoSpeakResponses,
                        onCheckedChange = onSetAutoSpeak
                    )
                    ToggleSettingRow(
                        title = "Proactive Next-Step Suggestions",
                        subtitle = "Show contextual follow-up actions and open reminder hints",
                        checked = preferences.proactiveSuggestionsEnabled,
                        onCheckedChange = onSetProactive
                    )

                    Column {
                        Text(
                            text = "Voice Speech Rate: ${String.format(Locale.US, "%.2f", preferences.speechRate)}x",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Slider(
                            value = preferences.speechRate,
                            onValueChange = onSetSpeechRate,
                            valueRange = 0.7f..1.5f
                        )
                    }
                }
            }

            // 3. Weather Fallback City
            item {
                ControlSectionCard(title = "Weather Fallback City") {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = cityInput,
                            onValueChange = { cityInput = it },
                            label = { Text("Default City") },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = { onSetDefaultCity(cityInput) }) {
                            Text("Save")
                        }
                    }
                }
            }

            // 4. Account & Firebase Security
            item {
                ControlSectionCard(title = "Account & Zero-Trust Cloud Security") {
                    Text(
                        text = userDisplayName ?: "Authenticated Operator",
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = userEmail ?: "Google Account Connected",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Cloud Sync: Active (Firebase Firestore Enterprise) • Gemini: Firebase AI Logic + App Check • Package: com.dn.mark1",
                        style = MaterialTheme.typography.labelSmall,
                        color = VerifiedEmerald
                    )
                    OutlinedButton(
                        onClick = onSignOut,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sign_out_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertCrimson),
                        border = BorderStroke(1.dp, AlertCrimson.copy(alpha = 0.6f))
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(stringResource(R.string.sign_out))
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlSectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = CommandSurface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = ArcCyan)
            content()
        }
    }
}

@Composable
private fun PermissionRow(
    icon: ImageVector,
    title: String,
    purpose: String,
    granted: Boolean,
    onGrant: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(icon, contentDescription = null, tint = if (granted) VerifiedEmerald else GateAmber, modifier = Modifier.size(22.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(purpose, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (granted) {
            StatusPill(label = "GRANTED", color = VerifiedEmerald)
        } else {
            Button(
                onClick = onGrant,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text("Grant")
            }
        }
    }
}

@Composable
private fun ToggleSettingRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
