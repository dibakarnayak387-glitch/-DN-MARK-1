package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep Obsidian Command Center surfaces
val ObsidianVoid = Color(0xFF040914)
val DeepSpace = Color(0xFF071122)
val CommandSurface = Color(0xFF0B172B)
val CommandSurfaceHigh = Color(0xFF11223E)
val CommandSurfaceHighest = Color(0xFF182F54)
val CommandOutline = Color(0xFF21426F)
val CommandOutlineSubtle = Color(0xFF162C4D)

// Luminous Jarvis Arc Reactor Cyan & Sapphire Accents
val ArcCyan = Color(0xFF00E5FF)
val ArcCyanSoft = Color(0xFF6FF7FF)
val ArcCyanDim = Color(0xFF004F5C)
val OnArcCyan = Color(0xFF002026)

val SapphireBlue = Color(0xFF3B82F6)
val SapphireContainer = Color(0xFF0D2854)
val OnSapphireContainer = Color(0xFFD6E6FF)

val ReactorTeal = Color(0xFF14B8A6)
val ReactorTealContainer = Color(0xFF093634)

// Telemetry & Verification Status Colors
val VerifiedEmerald = Color(0xFF00E676)
val VerifiedEmeraldContainer = Color(0xFF073620)
val GateAmber = Color(0xFFFFB300)
val GateAmberContainer = Color(0xFF3B2900)
val AlertCrimson = Color(0xFFFF5252)
val AlertCrimsonContainer = Color(0xFF471014)

// High-Contrast Text Tokens
val IceWhite = Color(0xFFEBF5FF)
val FrostSlate = Color(0xFF9EB5D1)
val MutedSteel = Color(0xFF6B84A3)
