package com.example.agent

import android.content.Context
import com.example.ai.AgentBrain
import com.example.ai.LanguageDetector
import com.example.data.local.CachedStepEntity
import com.example.data.local.CachedTaskPlanEntity
import com.example.data.local.Mark1StepDao
import com.example.data.local.Mark1TaskPlanDao
import com.example.data.model.AgentCoreState
import com.example.data.model.AgentIntentType
import com.example.data.model.AgentLanguage
import com.example.data.model.ConversationMessage
import com.example.data.model.LanguagePreference
import com.example.data.model.MemoryItem
import com.example.data.model.MemoryProposal
import com.example.data.model.MessageRole
import com.example.data.model.PendingTaskPlan
import com.example.data.model.PlannedStep
import com.example.data.model.StepStatus
import com.example.data.model.TaskStatus
import com.example.data.model.UserReminder
import com.example.data.remote.Mark1FirestoreRepository
import com.example.tools.AndroidToolRegistry
import com.example.tools.ToolExecutionResult
import com.example.tools.ToolParams
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

data class AgentEngineSnapshot(
    val coreState: AgentCoreState = AgentCoreState.IDLE,
    val activeTaskId: String? = null,
    val statusDetail: String = "Standing by for command",
    val pendingPlan: PendingTaskPlan? = null,
    val pendingMemoryProposal: MemoryProposal? = null,
    val permissionRequestNeeded: String? = null,
    val permissionRationale: String? = null,
    val proactiveSuggestions: List<String> = emptyList(),
    val lastError: String? = null
)

class WorkAgentEngine(
    private val appContext: Context,
    private val brain: AgentBrain,
    private val toolRegistry: AndroidToolRegistry,
    private val firestoreRepository: Mark1FirestoreRepository,
    private val stepDao: Mark1StepDao,
    private val taskPlanDao: Mark1TaskPlanDao
) {
    private val _state = MutableStateFlow(AgentEngineSnapshot())
    val state: StateFlow<AgentEngineSnapshot> = _state.asStateFlow()

    private val runningJobs = ConcurrentHashMap<String, Job>()
    private var lastSubmittedFingerprint: Pair<String, Long>? = null

    fun clearError() {
        _state.value = _state.value.copy(
            lastError = null,
            coreState = if (_state.value.coreState == AgentCoreState.ERROR) AgentCoreState.IDLE else _state.value.coreState
        )
    }

    fun dismissPermissionPrompt() {
        _state.value = _state.value.copy(
            permissionRequestNeeded = null,
            permissionRationale = null
        )
    }

    fun dismissMemoryProposal() {
        _state.value = _state.value.copy(pendingMemoryProposal = null)
    }

    fun submitCommand(
        scope: CoroutineScope,
        userId: String,
        rawPrompt: String,
        languagePreference: LanguagePreference,
        defaultCity: String,
        recentHistory: List<ConversationMessage>,
        memories: List<MemoryItem>,
        reminders: List<UserReminder>,
        onSpeakResponse: (String, AgentLanguage) -> Unit
    ) {
        val prompt = rawPrompt.trim()
        if (prompt.isEmpty()) return

        // Duplicate action prevention (3.5s debounce for identical command)
        val now = System.currentTimeMillis()
        val prev = lastSubmittedFingerprint
        if (prev != null && prev.first.equals(prompt, ignoreCase = true) && (now - prev.second) < 3500L) {
            return
        }
        lastSubmittedFingerprint = prompt to now

        val hintedLang = LanguageDetector.resolveLanguage(prompt, languagePreference)

        scope.launch {
            _state.value = _state.value.copy(
                coreState = AgentCoreState.THINKING,
                statusDetail = "Analyzing instruction & planning steps…",
                lastError = null
            )

            firestoreRepository.addConversationMessage(
                userId = userId,
                role = MessageRole.USER,
                text = prompt,
                language = hintedLang
            )

            val planResult = brain.planRequest(
                userPrompt = prompt,
                preferredLanguage = hintedLang,
                recentHistory = recentHistory,
                memories = memories,
                pendingReminders = reminders,
                toolCatalog = toolRegistry.describeCatalogForPrompt(),
                allowedToolNames = toolRegistry.allowedToolNames
            )

            planResult.onFailure { error ->
                val msg = error.localizedMessage ?: "Failed to process request with Gemini."
                _state.value = _state.value.copy(
                    coreState = AgentCoreState.ERROR,
                    statusDetail = "AI planning error",
                    lastError = msg
                )
                firestoreRepository.addConversationMessage(
                    userId = userId,
                    role = MessageRole.SYSTEM,
                    text = "Error: $msg",
                    language = hintedLang
                )
                return@launch
            }

            val plan = planResult.getOrThrow()
            val responseLang = if (languagePreference == LanguagePreference.AUTO) {
                plan.detectedLanguage
            } else {
                hintedLang
            }

            if (plan.proactiveSuggestions.isNotEmpty()) {
                _state.value = _state.value.copy(proactiveSuggestions = plan.proactiveSuggestions)
            }
            if (plan.memoryProposal != null) {
                _state.value = _state.value.copy(pendingMemoryProposal = plan.memoryProposal)
            }

            if (plan.steps.isEmpty() || plan.intentType == AgentIntentType.DIRECT_ANSWER || plan.intentType == AgentIntentType.CLARIFY) {
                firestoreRepository.addConversationMessage(
                    userId = userId,
                    role = MessageRole.ASSISTANT,
                    text = plan.assistantReply,
                    language = responseLang
                )
                _state.value = _state.value.copy(
                    coreState = AgentCoreState.IDLE,
                    statusDetail = "Ready"
                )
                onSpeakResponse(plan.assistantReply, responseLang)
                return@launch
            }

            // Create structured multi-step task
            val taskId = "task_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val initialStatus = if (plan.requiresConfirmation) {
                TaskStatus.AWAITING_CONFIRMATION
            } else {
                TaskStatus.RUNNING
            }
            val initialStepStatus = if (plan.requiresConfirmation) {
                StepStatus.AWAITING_CONFIRMATION
            } else {
                StepStatus.PENDING
            }

            val pendingPlan = PendingTaskPlan(
                taskId = taskId,
                userId = userId,
                title = plan.taskTitle.ifEmpty { prompt.take(60) },
                description = plan.taskDescription.ifEmpty { prompt },
                language = responseLang,
                steps = plan.steps,
                requiresConfirmation = plan.requiresConfirmation,
                originalPrompt = prompt
            )

            persistPlanToLocalCache(pendingPlan, initialStatus, initialStepStatus)
            firestoreRepository.createTask(
                userId = userId,
                taskId = taskId,
                title = pendingPlan.title,
                description = pendingPlan.description,
                language = responseLang,
                status = initialStatus,
                stepsCount = pendingPlan.steps.size,
                stepsSummary = pendingPlan.steps.map { "[PENDING] ${it.toolName}: ${it.title}" },
                requiresConfirmation = plan.requiresConfirmation
            )

            firestoreRepository.addConversationMessage(
                userId = userId,
                role = MessageRole.ASSISTANT,
                text = plan.assistantReply,
                language = responseLang,
                linkedTaskId = taskId
            )

            if (plan.requiresConfirmation) {
                _state.value = _state.value.copy(
                    coreState = AgentCoreState.AWAITING_CONFIRMATION,
                    activeTaskId = taskId,
                    pendingPlan = pendingPlan,
                    statusDetail = "Awaiting your confirmation (${plan.steps.size} steps)"
                )
                onSpeakResponse(plan.assistantReply, responseLang)
            } else {
                executePlan(
                    scope = scope,
                    plan = pendingPlan,
                    defaultCity = defaultCity,
                    openRemindersCount = reminders.count { !it.completed },
                    onSpeakResponse = onSpeakResponse
                )
            }
        }
    }

    fun approvePendingPlan(
        scope: CoroutineScope,
        defaultCity: String,
        openRemindersCount: Int,
        onSpeakResponse: (String, AgentLanguage) -> Unit
    ) {
        val plan = _state.value.pendingPlan ?: return
        _state.value = _state.value.copy(pendingPlan = null)
        executePlan(scope, plan, defaultCity, openRemindersCount, onSpeakResponse)
    }

    fun cancelTask(scope: CoroutineScope, userId: String, taskId: String) {
        runningJobs.remove(taskId)?.cancel()
        if (_state.value.pendingPlan?.taskId == taskId) {
            _state.value = _state.value.copy(pendingPlan = null)
        }
        scope.launch {
            val steps = stepDao.getStepsForTask(taskId)
            val updatedSteps = steps.map { step ->
                if (step.status == StepStatus.PENDING.name ||
                    step.status == StepStatus.RUNNING.name ||
                    step.status == StepStatus.AWAITING_CONFIRMATION.name
                ) {
                    step.copy(status = StepStatus.CANCELLED.name, updatedAtMillis = System.currentTimeMillis())
                } else step
            }
            if (updatedSteps.isNotEmpty()) {
                stepDao.upsertSteps(updatedSteps)
            }
            val doneCount = updatedSteps.count { it.status == StepStatus.VERIFIED.name }
            val progress = if (updatedSteps.isEmpty()) 0 else (doneCount * 100) / updatedSteps.size
            firestoreRepository.updateTaskProgress(
                userId = userId,
                taskId = taskId,
                status = TaskStatus.CANCELLED,
                progressPercent = progress,
                completedStepsCount = doneCount,
                stepsSummary = updatedSteps.map { "[${it.status}] ${it.toolName}: ${it.actualResult ?: it.title}" },
                summary = "Cancelled by user.",
                errorMessage = null,
                requiresConfirmation = false
            )
            _state.value = _state.value.copy(
                coreState = AgentCoreState.IDLE,
                activeTaskId = null,
                statusDetail = "Task cancelled safely"
            )
        }
    }

    fun retryTask(
        scope: CoroutineScope,
        userId: String,
        taskId: String,
        defaultCity: String,
        openRemindersCount: Int,
        onSpeakResponse: (String, AgentLanguage) -> Unit
    ) {
        if (runningJobs.containsKey(taskId)) return
        scope.launch {
            val cachedPlan = taskPlanDao.getTaskPlan(taskId)
            val cachedSteps = stepDao.getStepsForTask(taskId)
            if (cachedPlan == null || cachedSteps.isEmpty()) {
                _state.value = _state.value.copy(
                    lastError = "Original step plan for this task is not cached locally. Please re-issue the command."
                )
                return@launch
            }
            val plan = PendingTaskPlan(
                taskId = taskId,
                userId = userId,
                title = cachedPlan.title,
                description = cachedPlan.description,
                language = AgentLanguage.fromCode(cachedPlan.language),
                steps = cachedSteps.sortedBy { it.stepIndex }.map { entity ->
                    PlannedStep(
                        stepIndex = entity.stepIndex,
                        title = entity.title,
                        toolName = entity.toolName,
                        query = entity.query,
                        appName = entity.appName,
                        recipient = entity.recipient,
                        messageText = entity.messageText,
                        location = entity.location,
                        timeLabel = entity.timeLabel,
                        notes = entity.notes,
                        requiredPermission = entity.requiredPermission,
                        requiresConfirmation = entity.requiresConfirmation,
                        expectedResult = entity.expectedResult
                    )
                },
                requiresConfirmation = false,
                originalPrompt = cachedPlan.originalPrompt
            )
            executePlan(scope, plan, defaultCity, openRemindersCount, onSpeakResponse)
        }
    }

    private fun executePlan(
        scope: CoroutineScope,
        plan: PendingTaskPlan,
        defaultCity: String,
        openRemindersCount: Int,
        onSpeakResponse: (String, AgentLanguage) -> Unit
    ) {
        // Prevent duplicate concurrent execution of the same task
        if (runningJobs.containsKey(plan.taskId)) return

        val job = scope.launch {
            val totalSteps = plan.steps.size.coerceAtLeast(1)
            val outcomeLines = mutableListOf<String>()
            var verifiedCount = 0
            var failedCount = 0

            try {
                _state.value = _state.value.copy(
                    coreState = AgentCoreState.EXECUTING,
                    activeTaskId = plan.taskId,
                    statusDetail = "Executing ${plan.title}…",
                    lastError = null
                )

                firestoreRepository.updateTaskProgress(
                    userId = plan.userId,
                    taskId = plan.taskId,
                    status = TaskStatus.RUNNING,
                    progressPercent = 5,
                    completedStepsCount = 0,
                    stepsSummary = plan.steps.map { "[PENDING] ${it.toolName}: ${it.title}" },
                    errorMessage = null,
                    requiresConfirmation = false
                )

                for ((idx, step) in plan.steps.withIndex()) {
                    val stepKey = "${plan.taskId}_step_$idx"
                    _state.value = _state.value.copy(
                        statusDetail = "Step ${idx + 1}/$totalSteps: ${step.title}"
                    )

                    stepDao.upsertStep(
                        step.toEntity(
                            stepKey = stepKey,
                            taskId = plan.taskId,
                            userId = plan.userId,
                            status = StepStatus.RUNNING,
                            actualResult = null,
                            errorDetail = null,
                            recoveryNote = null
                        )
                    )

                    val result = toolRegistry.executeTool(
                        context = appContext,
                        toolName = step.toolName,
                        params = ToolParams(
                            userId = plan.userId,
                            language = plan.language,
                            query = step.query,
                            appName = step.appName,
                            recipient = step.recipient,
                            messageText = step.messageText,
                            title = step.title,
                            notes = step.notes,
                            location = step.location,
                            timeLabel = step.timeLabel,
                            defaultCity = defaultCity
                        )
                    )

                    when (result) {
                        is ToolExecutionResult.Success -> {
                            verifiedCount++
                            outcomeLines.add("[VERIFIED] ${step.toolName}: ${result.summary}")
                            stepDao.upsertStep(
                                step.toEntity(
                                    stepKey = stepKey,
                                    taskId = plan.taskId,
                                    userId = plan.userId,
                                    status = StepStatus.VERIFIED,
                                    actualResult = result.summary,
                                    errorDetail = null,
                                    recoveryNote = null
                                )
                            )
                        }

                        is ToolExecutionResult.NeedsPermission -> {
                            failedCount++
                            val line = "[PERMISSION REQUIRED] ${step.toolName}: ${result.rationale}"
                            outcomeLines.add(line)
                            _state.value = _state.value.copy(
                                permissionRequestNeeded = result.permission,
                                permissionRationale = result.rationale
                            )
                            stepDao.upsertStep(
                                step.toEntity(
                                    stepKey = stepKey,
                                    taskId = plan.taskId,
                                    userId = plan.userId,
                                    status = StepStatus.FAILED,
                                    actualResult = null,
                                    errorDetail = "Missing permission: ${result.permission}",
                                    recoveryNote = result.rationale
                                )
                            )
                        }

                        is ToolExecutionResult.Failure -> {
                            failedCount++
                            val recovery = result.fallbackSuggestion ?: "Retry after checking device state."
                            outcomeLines.add("[FAILED] ${step.toolName}: ${result.reason} (Recovery: $recovery)")
                            stepDao.upsertStep(
                                step.toEntity(
                                    stepKey = stepKey,
                                    taskId = plan.taskId,
                                    userId = plan.userId,
                                    status = StepStatus.FAILED,
                                    actualResult = null,
                                    errorDetail = result.reason,
                                    recoveryNote = recovery
                                )
                            )
                        }
                    }

                    val progress = (((idx + 1) * 100) / totalSteps).coerceIn(10, 99)
                    firestoreRepository.updateTaskProgress(
                        userId = plan.userId,
                        taskId = plan.taskId,
                        status = TaskStatus.RUNNING,
                        progressPercent = progress,
                        completedStepsCount = verifiedCount,
                        stepsSummary = outcomeLines.toList(),
                        errorMessage = if (failedCount > 0) "Some steps require attention." else null
                    )
                }

                val finalStatus = if (failedCount == 0) TaskStatus.COMPLETED else TaskStatus.FAILED
                val synthesized = brain.synthesizeExecutionReport(
                    originalPrompt = plan.originalPrompt,
                    language = plan.language,
                    stepOutcomeLines = outcomeLines,
                    pendingRemindersCount = openRemindersCount
                ).getOrElse {
                    outcomeLines.joinToString("\n")
                }

                firestoreRepository.updateTaskProgress(
                    userId = plan.userId,
                    taskId = plan.taskId,
                    status = finalStatus,
                    progressPercent = if (finalStatus == TaskStatus.COMPLETED) 100 else (verifiedCount * 100) / totalSteps,
                    completedStepsCount = verifiedCount,
                    stepsSummary = outcomeLines,
                    summary = synthesized,
                    errorMessage = if (finalStatus == TaskStatus.FAILED) {
                        "$failedCount of $totalSteps step(s) failed or need permission."
                    } else null,
                    requiresConfirmation = false
                )

                firestoreRepository.addConversationMessage(
                    userId = plan.userId,
                    role = MessageRole.ASSISTANT,
                    text = synthesized,
                    language = plan.language,
                    linkedTaskId = plan.taskId
                )

                _state.value = _state.value.copy(
                    coreState = if (finalStatus == TaskStatus.COMPLETED) AgentCoreState.IDLE else AgentCoreState.ERROR,
                    activeTaskId = null,
                    statusDetail = if (finalStatus == TaskStatus.COMPLETED) {
                        "Verified ($verifiedCount/$totalSteps steps)"
                    } else {
                        "Completed with $failedCount issue(s)"
                    }
                )
                onSpeakResponse(synthesized, plan.language)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "Unexpected execution error"
                firestoreRepository.updateTaskProgress(
                    userId = plan.userId,
                    taskId = plan.taskId,
                    status = TaskStatus.FAILED,
                    progressPercent = (verifiedCount * 100) / totalSteps,
                    completedStepsCount = verifiedCount,
                    stepsSummary = outcomeLines.ifEmpty { listOf("[FAILED] $msg") },
                    errorMessage = msg
                )
                _state.value = _state.value.copy(
                    coreState = AgentCoreState.ERROR,
                    activeTaskId = null,
                    lastError = msg,
                    statusDetail = "Execution failed"
                )
            } finally {
                runningJobs.remove(plan.taskId)
            }
        }
        runningJobs[plan.taskId] = job
    }

    private suspend fun persistPlanToLocalCache(
        plan: PendingTaskPlan,
        taskStatus: TaskStatus,
        stepStatus: StepStatus
    ) {
        taskPlanDao.upsertTaskPlan(
            CachedTaskPlanEntity(
                taskId = plan.taskId,
                userId = plan.userId,
                title = plan.title,
                description = plan.description,
                language = plan.language.code,
                originalPrompt = plan.originalPrompt,
                status = taskStatus.name
            )
        )
        val entities = plan.steps.mapIndexed { idx, step ->
            step.toEntity(
                stepKey = "${plan.taskId}_step_$idx",
                taskId = plan.taskId,
                userId = plan.userId,
                status = stepStatus,
                actualResult = null,
                errorDetail = null,
                recoveryNote = null
            )
        }
        stepDao.upsertSteps(entities)
    }

    private fun PlannedStep.toEntity(
        stepKey: String,
        taskId: String,
        userId: String,
        status: StepStatus,
        actualResult: String?,
        errorDetail: String?,
        recoveryNote: String?
    ): CachedStepEntity = CachedStepEntity(
        stepKey = stepKey,
        taskId = taskId,
        userId = userId,
        stepIndex = stepIndex,
        title = title,
        toolName = toolName,
        query = query,
        appName = appName,
        recipient = recipient,
        messageText = messageText,
        location = location,
        timeLabel = timeLabel,
        notes = notes,
        requiredPermission = requiredPermission,
        requiresConfirmation = requiresConfirmation,
        expectedResult = expectedResult,
        status = status.name,
        actualResult = actualResult,
        errorDetail = errorDetail,
        recoveryNote = recoveryNote,
        updatedAtMillis = System.currentTimeMillis()
    )
}
