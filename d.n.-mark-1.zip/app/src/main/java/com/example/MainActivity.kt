package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.auth.authStateFlow
import com.example.auth.signOutUser
import com.example.data.local.Mark1Database
import com.example.data.model.AgentLanguage
import com.example.data.model.UiState
import com.example.data.prefs.UserPreferencesRepository
import com.example.data.remote.Mark1FirestoreRepository
import com.example.firebase.configureAppCheck
import com.example.tools.ToolUiBridge
import com.example.ui.Mark1ViewModel
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.CommandCoreScreen
import com.example.ui.screens.HistoryToolsScreen
import com.example.ui.screens.MemoryDashboardScreen
import com.example.ui.screens.SettingsPermissionsScreen
import com.example.ui.screens.TasksDashboardScreen
import com.example.ui.theme.CommandSurface
import com.example.ui.theme.DeepSpace
import com.example.ui.theme.Mark1Theme
import com.example.ui.theme.ObsidianVoid
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import java.io.File

private enum class Mark1Tab(
    val route: String,
    val labelRes: Int,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
) {
    CORE("core", R.string.nav_core, Icons.Filled.Hub, Icons.Outlined.Hub),
    TASKS("tasks", R.string.nav_tasks, Icons.Filled.Checklist, Icons.Outlined.Checklist),
    MEMORY("memory", R.string.nav_memory, Icons.Filled.Psychology, Icons.Outlined.Psychology),
    HISTORY("history", R.string.nav_history, Icons.Filled.Build, Icons.Outlined.Build),
    SETTINGS("settings", R.string.nav_settings, Icons.Filled.Tune, Icons.Outlined.Tune)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1 (MANDATORY): Configure App Check with launch intent before Compose UI, ViewModels, or Firebase ops
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        setContent {
            Mark1Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@Composable
fun AppNavigation(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser

    if (user == null) {
        AuthScreen(onAuthSuccess = {})
    } else {
        key(user.uid) {
            Mark1CommandCenter(
                currentUserId = user.uid,
                userEmail = user.email,
                userDisplayName = user.displayName
            )
        }
    }
}

@Composable
private fun Mark1CommandCenter(
    currentUserId: String,
    userEmail: String?,
    userDisplayName: String?
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val viewModel: Mark1ViewModel = viewModel(
        key = currentUserId,
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                val databaseId = app.getString(R.string.firestore_database_id)
                val db = FirebaseFirestore.getInstance(databaseId)
                Mark1ViewModel(
                    appContext = app,
                    currentUserId = currentUserId,
                    firestoreRepository = Mark1FirestoreRepository(db),
                    database = Mark1Database.getInstance(app),
                    prefsRepository = UserPreferencesRepository(app)
                )
            }
        }
    )

    val conversationsState by viewModel.conversationsState.collectAsStateWithLifecycle()
    val tasksState by viewModel.tasksState.collectAsStateWithLifecycle()
    val memoriesState by viewModel.memoriesState.collectAsStateWithLifecycle()
    val remindersState by viewModel.remindersState.collectAsStateWithLifecycle()
    val localStepsByTask by viewModel.localStepsByTask.collectAsStateWithLifecycle()
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()
    val engineState by viewModel.engineState.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val isVoiceServiceRunning by viewModel.isVoiceServiceRunning.collectAsStateWithLifecycle()
    val coreState by viewModel.effectiveCoreState.collectAsStateWithLifecycle()
    val photoDraft by viewModel.photoDraft.collectAsStateWithLifecycle()
    val toastBanner by viewModel.toastBanner.collectAsStateWithLifecycle()
    val quickToolResults by viewModel.quickToolResults.collectAsStateWithLifecycle()

    var selectedTab by rememberSaveable { mutableStateOf(Mark1Tab.CORE) }
    var permissionRefreshKey by remember { mutableIntStateOf(0) }
    var pendingPhotoUri by remember { mutableStateOf<Uri?>(null) }
    var pendingPhotoCaption by remember { mutableStateOf("Captured via D.N. Mark 1") }
    val snackbarHostState = remember { SnackbarHostState() }

    if (selectedTab != Mark1Tab.CORE) {
        BackHandler { selectedTab = Mark1Tab.CORE }
    }

    LaunchedEffect(toastBanner) {
        toastBanner?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.dismissBanner()
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionRefreshKey++
        viewModel.showBanner(
            if (granted) "Permission granted." else "Permission denied. You can enable it in Control > Permissions."
        )
    }

    val takePictureLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success ->
        val uri = pendingPhotoUri
        if (success && uri != null) {
            viewModel.setCapturedPhoto(uri.toString(), pendingPhotoCaption)
            selectedTab = Mark1Tab.CORE
            viewModel.showBanner("Photo captured! Review and tap Share via Android.")
        } else {
            viewModel.showBanner("Camera capture cancelled.")
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.setCapturedPhoto(uri.toString(), pendingPhotoCaption)
            selectedTab = Mark1Tab.CORE
            viewModel.showBanner("Photo selected! Review and tap Share via Android.")
        }
    }

    fun launchCameraCaptureFlow(caption: String): Boolean {
        return try {
            val photosDir = File(context.cacheDir, "photos").apply { mkdirs() }
            val photoFile = File(photosDir, "mark1_${System.currentTimeMillis()}.jpg")
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                photoFile
            )
            pendingPhotoUri = uri
            pendingPhotoCaption = caption
            takePictureLauncher.launch(uri)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchPhotoPickerFlow(caption: String): Boolean {
        return try {
            pendingPhotoCaption = caption
            photoPickerLauncher.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchShareTextFlow(text: String, subject: String?): Boolean {
        return try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
                if (!subject.isNullOrBlank()) putExtra(Intent.EXTRA_SUBJECT, subject)
            }
            val chooser = Intent.createChooser(sendIntent, "Share via D.N. Mark 1")
            context.startActivity(chooser)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchSharePhotoFlow(uriString: String, caption: String) {
        try {
            val uri = Uri.parse(uriString)
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, caption)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(shareIntent, "Share photo"))
        } catch (e: Exception) {
            viewModel.showBanner("Could not open share sheet: ${e.localizedMessage}")
        }
    }

    DisposableEffect(viewModel) {
        viewModel.attachUiBridge(object : ToolUiBridge {
            override fun requestCameraCapture(caption: String): Boolean = launchCameraCaptureFlow(caption)
            override fun requestPhotoPicker(caption: String): Boolean = launchPhotoPickerFlow(caption)
            override fun launchShareText(text: String, subject: String?): Boolean = launchShareTextFlow(text, subject)
            override fun speakAloud(text: String, language: AgentLanguage): Boolean = viewModel.speakText(text, language)
        })
        onDispose { viewModel.attachUiBridge(null) }
    }

    val openRemindersCount = (remindersState as? UiState.Success)?.data?.count { !it.completed } ?: 0
    val hasMicPermission = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(ObsidianVoid, DeepSpace, ObsidianVoid)))
    ) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            containerColor = androidx.compose.ui.graphics.Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            snackbarHost = { SnackbarHost(snackbarHostState) },
            bottomBar = {
                if (!useRail) {
                    NavigationBar(containerColor = CommandSurface) {
                        Mark1Tab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes), maxLines = 1) },
                                modifier = Modifier.testTag("nav_${tab.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (useRail) {
                    NavigationRail(containerColor = CommandSurface) {
                        Mark1Tab.entries.forEach { tab ->
                            val selected = selectedTab == tab
                            NavigationRailItem(
                                selected = selected,
                                onClick = { selectedTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
                                        contentDescription = stringResource(tab.labelRes)
                                    )
                                },
                                label = { Text(stringResource(tab.labelRes)) },
                                modifier = Modifier.testTag("nav_${tab.route}")
                            )
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f).fillMaxSize()) {
                    when (selectedTab) {
                        Mark1Tab.CORE -> CommandCoreScreen(
                            conversationsState = conversationsState,
                            coreState = coreState,
                            engineState = engineState,
                            voiceState = voiceState,
                            isVoiceServiceRunning = isVoiceServiceRunning,
                            preferences = preferences,
                            photoDraft = photoDraft,
                            openRemindersCount = openRemindersCount,
                            onSendCommand = { viewModel.sendUserCommand(it) },
                            onMicToggle = {
                                viewModel.toggleListening(
                                    hasMicPermission = hasMicPermission,
                                    onRequestMicPermission = {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                )
                            },
                            onStopListening = { viewModel.stopAllListening() },
                            onStopSpeaking = { viewModel.stopSpeaking() },
                            onSpeakMessage = { txt, lang -> viewModel.speakText(txt, lang) },
                            onLanguageChange = { viewModel.setLanguagePreference(it) },
                            onApprovePlan = { viewModel.approvePendingPlan() },
                            onCancelTask = { viewModel.cancelTask(it) },
                            onApproveMemory = { viewModel.approveMemoryProposal() },
                            onDismissMemory = { viewModel.dismissMemoryProposal() },
                            onRequestPermission = { perm -> permissionLauncher.launch(perm) },
                            onDismissPermission = { viewModel.dismissPermissionPrompt() },
                            onPickPhoto = { launchPhotoPickerFlow("Shared via D.N. Mark 1") },
                            onSharePhotoDraft = { draft ->
                                launchSharePhotoFlow(draft.uriString, draft.caption)
                                viewModel.clearPhotoDraft()
                            },
                            onDismissPhotoDraft = { viewModel.clearPhotoDraft() },
                            onClearError = { viewModel.clearEngineError() },
                            onClearVoiceError = { viewModel.clearVoiceError() }
                        )

                        Mark1Tab.TASKS -> TasksDashboardScreen(
                            tasksState = tasksState,
                            localStepsByTask = localStepsByTask,
                            pendingPlanTaskId = engineState.pendingPlan?.taskId,
                            onApprovePending = { viewModel.approvePendingPlan() },
                            onCancelTask = { viewModel.cancelTask(it) },
                            onRetryTask = { viewModel.retryTask(it) },
                            onDeleteTask = { viewModel.deleteTask(it) }
                        )

                        Mark1Tab.MEMORY -> MemoryDashboardScreen(
                            memoriesState = memoriesState,
                            remindersState = remindersState,
                            onAddMemory = { cat, title, content, lang, pinned ->
                                viewModel.addMemory(cat, title, content, lang, pinned)
                            },
                            onUpdateMemory = { id, cat, title, content, lang, pinned ->
                                viewModel.updateMemory(id, cat, title, content, lang, pinned)
                            },
                            onDeleteMemory = { viewModel.deleteMemory(it) },
                            onAddReminder = { title, time, notes ->
                                viewModel.addReminder(title, time, notes)
                            },
                            onToggleReminder = { id, done -> viewModel.toggleReminder(id, done) },
                            onDeleteReminder = { viewModel.deleteReminder(it) }
                        )

                        Mark1Tab.HISTORY -> HistoryToolsScreen(
                            tools = viewModel.toolRegistry.allTools,
                            quickToolResults = quickToolResults,
                            conversationsState = conversationsState,
                            onRunToolDiagnostic = { viewModel.runQuickToolCheck(it) },
                            onClearHistory = { viewModel.clearConversations() }
                        )

                        Mark1Tab.SETTINGS -> SettingsPermissionsScreen(
                            userEmail = userEmail,
                            userDisplayName = userDisplayName,
                            preferences = preferences,
                            isVoiceServiceRunning = isVoiceServiceRunning,
                            permissionRefreshKey = permissionRefreshKey,
                            onRequestPermission = { perm -> permissionLauncher.launch(perm) },
                            onStartVoiceService = {
                                viewModel.startForegroundVoiceSession(
                                    hasMicPermission = hasMicPermission,
                                    onRequestMicPermission = {
                                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                    }
                                )
                            },
                            onStopVoiceService = { viewModel.stopAllListening() },
                            onSetContinuous = { viewModel.setContinuousConversation(it) },
                            onSetWakePhrase = { viewModel.setWakePhraseFilter(it) },
                            onSetAutoSpeak = { viewModel.setAutoSpeak(it) },
                            onSetSpeechRate = { viewModel.setSpeechRate(it) },
                            onSetProactive = { viewModel.setProactiveSuggestions(it) },
                            onSetDefaultCity = { viewModel.setDefaultCity(it) },
                            onSignOut = {
                                signOutUser(
                                    credentialManager = credentialManager,
                                    scope = scope,
                                    onBeforeSignOut = { viewModel.cleanupBeforeSignOut() }
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}
