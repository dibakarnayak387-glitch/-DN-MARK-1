package com.example.tools

import android.content.Context
import com.example.data.remote.Mark1FirestoreRepository

class AndroidToolRegistry(
    firestoreRepository: Mark1FirestoreRepository,
    bridgeProvider: () -> ToolUiBridge?
) {
    private val toolsMap: LinkedHashMap<String, AgentTool> = linkedMapOf<String, AgentTool>().apply {
        val all = listOf(
            CheckBatteryTool(),
            CheckChargingStatusTool(),
            GetWeatherTool(),
            InternetSearchTool(),
            YouTubeSearchTool(),
            OpenAppTool(),
            OpenCameraShareTool(bridgeProvider),
            PrepareWhatsAppTool(bridgeProvider),
            AndroidShareSheetTool(bridgeProvider),
            SendNotificationTool(),
            GetDeviceInfoTool(),
            CreateReminderTool(firestoreRepository),
            CreateLocalTaskTool(firestoreRepository),
            ReadAloudTool(bridgeProvider)
        )
        all.forEach { put(it.name, it) }
    }

    val allTools: List<AgentTool> get() = toolsMap.values.toList()
    val allowedToolNames: List<String> get() = toolsMap.keys.toList()

    fun getTool(name: String): AgentTool? = toolsMap[name.trim().lowercase()]

    suspend fun executeTool(
        context: Context,
        toolName: String,
        params: ToolParams
    ): ToolExecutionResult {
        val tool = getTool(toolName)
            ?: return ToolExecutionResult.Failure(
                reason = "Blocked: '$toolName' is not a registered, authorized Android tool.",
                recoverable = false
            )
        return tool.execute(context, params)
    }

    fun describeCatalogForPrompt(): String {
        return allTools.joinToString("\n") { tool ->
            val perms = if (tool.requiredPermissions.isEmpty()) "none" else tool.requiredPermissions.joinToString()
            val confirm = if (tool.requiresConfirmation) "REQUIRES_USER_CONFIRMATION" else "auto-safe"
            val schema = if (tool.inputSchema.isEmpty()) "no inputs" else tool.inputSchema.entries.joinToString { "${it.key}: ${it.value}" }
            "- ${tool.name} ($confirm, perms: $perms): ${tool.description} Inputs: [$schema]"
        }
    }
}
