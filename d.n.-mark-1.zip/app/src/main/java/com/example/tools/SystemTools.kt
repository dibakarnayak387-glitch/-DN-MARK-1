package com.example.tools

import android.Manifest
import android.annotation.SuppressLint
import android.app.ActivityManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.os.StatFs
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.R
import com.example.data.remote.OpenMeteoClient
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.roundToInt

class CheckBatteryTool : AgentTool {
    override val name = "check_battery"
    override val displayName = "Battery Telemetry"
    override val description = "Reads real-time battery percentage, temperature, voltage, and health."
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return ToolExecutionResult.Failure("Unable to read battery telemetry from Android system.")

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val percent = if (level >= 0) ((level * 100f) / scale).roundToInt() else -1
        if (percent < 0) {
            return ToolExecutionResult.Failure("Battery level unavailable from device sensors.")
        }

        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0)
        val tempC = tempTenths / 10.0
        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0)
        val healthCode = intent.getIntExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_UNKNOWN)
        val health = when (healthCode) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good"
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheat"
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead"
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over Voltage"
            BatteryManager.BATTERY_HEALTH_COLD -> "Cold"
            else -> "Normal"
        }

        val summary = "Battery is at $percent% (${String.format(Locale.US, "%.1f", tempC)}°C, Health: $health)."
        return ToolExecutionResult.Success(
            summary = summary,
            details = mapOf(
                "percent" to "$percent%",
                "temperatureC" to "${String.format(Locale.US, "%.1f", tempC)}°C",
                "voltageMv" to "${voltageMv} mV",
                "health" to health
            )
        )
    }
}

class CheckChargingStatusTool : AgentTool {
    override val name = "check_charging_status"
    override val displayName = "Charging & Power Status"
    override val description = "Checks whether the phone is charging, plug source (AC/USB/Wireless), and Battery Saver."
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            ?: return ToolExecutionResult.Failure("Unable to inspect charging state.")

        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val statusLabel = when (status) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "Charging"
            BatteryManager.BATTERY_STATUS_FULL -> "Fully Charged"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "Discharging"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "Not Charging"
            else -> "Unknown"
        }
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
        val plugLabel = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_AC -> "AC Wall Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB Port"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless Pad"
            else -> "Unplugged"
        }
        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val powerSave = powerManager?.isPowerSaveMode == true

        val summary = if (isCharging) {
            "Device is $statusLabel via $plugLabel. Battery Saver: ${if (powerSave) "On" else "Off"}."
        } else {
            "Device is $statusLabel ($plugLabel). Battery Saver: ${if (powerSave) "On" else "Off"}."
        }
        return ToolExecutionResult.Success(
            summary = summary,
            details = mapOf(
                "status" to statusLabel,
                "source" to plugLabel,
                "batterySaver" to if (powerSave) "Enabled" else "Disabled"
            )
        )
    }
}

class GetDeviceInfoTool : AgentTool {
    override val name = "get_device_info"
    override val displayName = "Device Diagnostics"
    override val description = "Reads real Android OS version, hardware model, memory, storage, and network status."
    override val inputSchema = emptyMap<String, String>()
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am?.getMemoryInfo(memInfo)
        val availRamGb = memInfo.availMem / (1024.0 * 1024.0 * 1024.0)
        val totalRamGb = memInfo.totalMem / (1024.0 * 1024.0 * 1024.0)

        val stat = StatFs(Environment.getDataDirectory().path)
        val freeStorageGb = (stat.availableBlocksLong * stat.blockSizeLong) / (1024.0 * 1024.0 * 1024.0)

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val activeNet = cm?.activeNetwork
        val caps = if (activeNet != null) cm.getNetworkCapabilities(activeNet) else null
        val networkLabel = when {
            caps == null -> "Offline"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Connected"
        }

        val deviceName = "${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}"
        val summary = "$deviceName • Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}) • " +
            "RAM ${String.format(Locale.US, "%.1f", availRamGb)}/${String.format(Locale.US, "%.1f", totalRamGb)} GB free • " +
            "Storage ${String.format(Locale.US, "%.1f", freeStorageGb)} GB free • Network: $networkLabel."

        return ToolExecutionResult.Success(
            summary = summary,
            details = mapOf(
                "model" to deviceName,
                "android" to "Android ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})",
                "ram" to "${String.format(Locale.US, "%.1f", availRamGb)} / ${String.format(Locale.US, "%.1f", totalRamGb)} GB",
                "storageFree" to "${String.format(Locale.US, "%.1f", freeStorageGb)} GB",
                "network" to networkLabel
            )
        )
    }
}

class GetWeatherTool : AgentTool {
    override val name = "get_weather"
    override val displayName = "Live Weather"
    override val description = "Fetches real-time weather using Open-Meteo from device coarse location or specified city."
    override val inputSchema = mapOf("location" to "Optional city name (falls back to device location or default city)")
    override val requiredPermissions = emptyList<String>() // Works via city geocoding even without location permission
    override val requiresConfirmation = false

    @SuppressLint("MissingPermission")
    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        return withContext(Dispatchers.IO) {
            try {
                val requestedCity = params.location?.trim()?.takeIf { it.isNotEmpty() }
                var lat: Double? = null
                var lon: Double? = null
                var resolvedLabel: String? = null

                // 1. If no explicit city requested and coarse location granted, try device location
                val hasCoarseLocation = ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED

                if (requestedCity == null && hasCoarseLocation) {
                    try {
                        val fused = LocationServices.getFusedLocationProviderClient(context)
                        val loc = fused.lastLocation.await()
                        if (loc != null) {
                            lat = loc.latitude
                            lon = loc.longitude
                            resolvedLabel = "Current Location"
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        // Fall back cleanly to city geocoding
                    }
                }

                // 2. Geocode requested city or configured default city
                if (lat == null || lon == null) {
                    val cityQuery = requestedCity ?: params.defaultCity
                    val geo = OpenMeteoClient.geocodingApi.searchCity(name = cityQuery)
                    val match = geo.results?.firstOrNull()
                        ?: return@withContext ToolExecutionResult.Failure(
                            reason = "Could not find weather coordinates for '$cityQuery'.",
                            fallbackSuggestion = "Try specifying a major nearby city name."
                        )
                    lat = match.latitude
                    lon = match.longitude
                    resolvedLabel = listOfNotNull(match.name, match.admin1, match.country)
                        .distinct()
                        .joinToString(", ")
                }

                val forecast = OpenMeteoClient.weatherApi.getCurrentWeather(lat, lon)
                val current = forecast.current
                    ?: return@withContext ToolExecutionResult.Failure("Weather service returned empty current conditions.")

                val temp = current.temperatureC?.roundToInt()
                val feelsLike = current.feelsLikeC?.roundToInt()
                val humidity = current.humidityPercent
                val wind = current.windSpeedKmh?.roundToInt()
                val condition = OpenMeteoClient.describeWeatherCode(current.weatherCode)

                val summary = "Weather in $resolvedLabel: ${temp ?: "--"}°C ($condition), " +
                    "feels like ${feelsLike ?: "--"}°C, humidity ${humidity ?: "--"}%, wind ${wind ?: "--"} km/h."

                ToolExecutionResult.Success(
                    summary = summary,
                    details = mapOf(
                        "location" to (resolvedLabel ?: "Unknown"),
                        "temperature" to "${temp ?: "--"}°C",
                        "condition" to condition,
                        "humidity" to "${humidity ?: "--"}%",
                        "wind" to "${wind ?: "--"} km/h"
                    )
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ToolExecutionResult.Failure(
                    reason = "Weather fetch failed: ${e.localizedMessage ?: "Network unavailable"}",
                    fallbackSuggestion = "Check internet connectivity and retry."
                )
            }
        }
    }
}

class SendNotificationTool : AgentTool {
    override val name = "send_notification"
    override val displayName = "System Notification"
    override val description = "Posts a verified local Android notification on the D.N. Mark 1 Alerts channel."
    override val inputSchema = mapOf(
        "title" to "Notification title",
        "messageText" to "Notification body text"
    )
    override val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        listOf(Manifest.permission.POST_NOTIFICATIONS)
    } else {
        emptyList()
    }
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        if (!hasPermissions(context)) {
            return ToolExecutionResult.NeedsPermission(
                permission = Manifest.permission.POST_NOTIFICATIONS,
                rationale = "Allow notifications so D.N. Mark 1 can post task and reminder alerts."
            )
        }

        val title = params.title?.trim()?.takeIf { it.isNotEmpty() } ?: "D.N. Mark 1 Alert"
        val body = params.messageText?.trim()?.takeIf { it.isNotEmpty() }
            ?: params.notes?.trim()?.takeIf { it.isNotEmpty() }
            ?: "Action completed."

        return try {
            ensureAlertChannel(context)
            val notificationId = (System.currentTimeMillis() % 100_000).toInt() + 2000
            val notification = NotificationCompat.Builder(context, ALERTS_CHANNEL_ID)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(body))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()

            NotificationManagerCompat.from(context).notify(notificationId, notification)
            ToolExecutionResult.Success(
                summary = "Notification posted: \"$title\"",
                details = mapOf("title" to title, "body" to body)
            )
        } catch (e: SecurityException) {
            ToolExecutionResult.NeedsPermission(
                permission = Manifest.permission.POST_NOTIFICATIONS,
                rationale = "Notification permission was denied by the OS."
            )
        } catch (e: Exception) {
            ToolExecutionResult.Failure("Failed to post notification: ${e.localizedMessage}")
        }
    }

    companion object {
        const val ALERTS_CHANNEL_ID = "dn_mark1_alerts"

        fun ensureAlertChannel(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(ALERTS_CHANNEL_ID) == null) {
                    val channel = NotificationChannel(
                        ALERTS_CHANNEL_ID,
                        context.getString(R.string.alerts_channel_name),
                        NotificationManager.IMPORTANCE_DEFAULT
                    ).apply {
                        description = context.getString(R.string.alerts_channel_desc)
                    }
                    nm.createNotificationChannel(channel)
                }
            }
        }
    }
}

class ReadAloudTool(private val bridgeProvider: () -> ToolUiBridge?) : AgentTool {
    override val name = "read_aloud"
    override val displayName = "Read Aloud (TTS)"
    override val description = "Speaks selected information aloud using Android Text-to-Speech in English, Hindi, or Odia."
    override val inputSchema = mapOf("messageText" to "Text to read aloud")
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val text = params.messageText?.trim()?.takeIf { it.isNotEmpty() }
            ?: params.query?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("No text was provided to read aloud.")

        val bridge = bridgeProvider()
            ?: return ToolExecutionResult.Failure("Voice output bridge is not attached.")

        val started = bridge.speakAloud(text, params.language)
        return if (started) {
            ToolExecutionResult.Success(
                summary = "Reading aloud in ${params.language.displayName}.",
                details = mapOf("language" to params.language.displayName, "chars" to text.length.toString())
            )
        } else {
            ToolExecutionResult.Failure("Text-to-Speech engine is initializing or unavailable on this device.")
        }
    }
}
