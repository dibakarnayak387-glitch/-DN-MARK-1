package com.example.tools

import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.example.data.model.AgentLanguage

data class ToolParams(
    val userId: String,
    val language: AgentLanguage = AgentLanguage.ENGLISH,
    val query: String? = null,
    val appName: String? = null,
    val recipient: String? = null,
    val messageText: String? = null,
    val title: String? = null,
    val notes: String? = null,
    val location: String? = null,
    val timeLabel: String? = null,
    val defaultCity: String = "Bhubaneswar"
)

sealed interface ToolExecutionResult {
    data class Success(
        val summary: String,
        val details: Map<String, String> = emptyMap(),
        val verified: Boolean = true
    ) : ToolExecutionResult

    data class NeedsPermission(
        val permission: String,
        val rationale: String
    ) : ToolExecutionResult

    data class Failure(
        val reason: String,
        val recoverable: Boolean = true,
        val fallbackSuggestion: String? = null
    ) : ToolExecutionResult
}

/**
 * Bridge allowing Android tools to trigger Activity-scoped UI flows (Camera capture,
 * Photo Picker, Android Share Sheet, TTS playback) cleanly without leaking Activity references.
 */
interface ToolUiBridge {
    fun requestCameraCapture(caption: String): Boolean
    fun requestPhotoPicker(caption: String): Boolean
    fun launchShareText(text: String, subject: String? = null): Boolean
    fun speakAloud(text: String, language: AgentLanguage): Boolean
}

interface AgentTool {
    val name: String
    val displayName: String
    val description: String
    val inputSchema: Map<String, String>
    val requiredPermissions: List<String>
    val requiresConfirmation: Boolean

    fun hasPermissions(context: Context): Boolean {
        return requiredPermissions.all { perm ->
            ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
        }
    }

    suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult
}
