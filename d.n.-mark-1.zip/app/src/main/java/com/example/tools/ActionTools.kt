package com.example.tools

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.example.data.remote.Mark1FirestoreRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class OpenAppTool : AgentTool {
    override val name = "open_app"
    override val displayName = "Launch Installed App"
    override val description = "Opens supported installed Android apps using verified package intents without QUERY_ALL_PACKAGES."
    override val inputSchema = mapOf("appName" to "App name such as YouTube, WhatsApp, Chrome, Maps, Settings, Clock, Calendar, Gmail, Calculator")
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    private val knownPackages = mapOf(
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "youtube" to listOf("com.google.android.youtube"),
        "chrome" to listOf("com.android.chrome"),
        "browser" to listOf("com.android.chrome"),
        "gmail" to listOf("com.google.android.gm"),
        "email" to listOf("com.google.android.gm"),
        "maps" to listOf("com.google.android.apps.maps"),
        "google maps" to listOf("com.google.android.apps.maps"),
        "calendar" to listOf("com.google.android.calendar"),
        "clock" to listOf("com.google.android.deskclock"),
        "alarm" to listOf("com.google.android.deskclock"),
        "calculator" to listOf("com.google.android.calculator"),
        "contacts" to listOf("com.google.android.contacts")
    )

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val requested = params.appName?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
            ?: params.query?.trim()?.lowercase()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("Please specify which app to open.")

        return withContext(Dispatchers.Main) {
            try {
                if (requested.contains("setting")) {
                    val settingsIntent = Intent(Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(settingsIntent)
                    return@withContext ToolExecutionResult.Success("Opened Android Settings.")
                }

                val candidatePackages = knownPackages.entries
                    .firstOrNull { requested.contains(it.key) }
                    ?.value
                    ?: listOf(requested)

                for (pkg in candidatePackages) {
                    val launchIntent = context.packageManager.getLaunchIntentForPackage(pkg)
                    if (launchIntent != null) {
                        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(launchIntent)
                        return@withContext ToolExecutionResult.Success(
                            summary = "Opened ${params.appName ?: pkg}.",
                            details = mapOf("package" to pkg)
                        )
                    }
                }

                ToolExecutionResult.Failure(
                    reason = "App '${params.appName ?: requested}' is not installed or not exposed to standard launch intents.",
                    fallbackSuggestion = "You can search for it on Google Play or open it via web search."
                )
            } catch (e: Exception) {
                ToolExecutionResult.Failure("Could not open app '${params.appName}': ${e.localizedMessage}")
            }
        }
    }
}

class InternetSearchTool : AgentTool {
    override val name = "internet_search"
    override val displayName = "Internet Search"
    override val description = "Opens an Android browser search intent for the requested query."
    override val inputSchema = mapOf("query" to "Search keywords")
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val q = params.query?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("Search query is empty.")
        val url = "https://www.google.com/search?q=${Uri.encode(q)}"

        return withContext(Dispatchers.Main) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (intent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(intent)
                    ToolExecutionResult.Success(
                        summary = "Opened web search for \"$q\".",
                        details = mapOf("query" to q, "url" to url)
                    )
                } else {
                    ToolExecutionResult.Failure("No web browser app is available to handle search URLs.")
                }
            } catch (e: Exception) {
                ToolExecutionResult.Failure("Failed to launch internet search: ${e.localizedMessage}")
            }
        }
    }
}

class YouTubeSearchTool : AgentTool {
    override val name = "youtube_search"
    override val displayName = "YouTube Search"
    override val description = "Opens YouTube search results for a topic in the YouTube app or browser."
    override val inputSchema = mapOf("query" to "Video search topic")
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = false

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val q = params.query?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("YouTube search query is empty.")
        val encoded = Uri.encode(q)
        val webUrl = "https://www.youtube.com/results?search_query=$encoded"

        return withContext(Dispatchers.Main) {
            try {
                val ytIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    setPackage("com.google.android.youtube")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (ytIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(ytIntent)
                    return@withContext ToolExecutionResult.Success(
                        summary = "Opened YouTube app searching for \"$q\".",
                        details = mapOf("query" to q, "target" to "YouTube App")
                    )
                }

                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(webUrl)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (browserIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(browserIntent)
                    return@withContext ToolExecutionResult.Success(
                        summary = "Opened YouTube search in browser for \"$q\".",
                        details = mapOf("query" to q, "target" to "Browser")
                    )
                }

                ToolExecutionResult.Failure("Neither YouTube nor a web browser is available on this device.")
            } catch (e: Exception) {
                ToolExecutionResult.Failure("Failed to launch YouTube search: ${e.localizedMessage}")
            }
        }
    }
}

class PrepareWhatsAppTool(private val bridgeProvider: () -> ToolUiBridge?) : AgentTool {
    override val name = "prepare_whatsapp_message"
    override val displayName = "Prepare WhatsApp Message"
    override val description = "Prepares a message draft and opens WhatsApp's supported sharing flow so the user selects the recipient and approves sending."
    override val inputSchema = mapOf(
        "recipient" to "Intended contact name (shown for user review)",
        "messageText" to "Draft message body"
    )
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = true

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val draft = params.messageText?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("Message text is empty.")
        val recipientHint = params.recipient?.trim()?.takeIf { it.isNotEmpty() }

        return withContext(Dispatchers.Main) {
            try {
                val waIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    setPackage("com.whatsapp")
                    putExtra(Intent.EXTRA_TEXT, draft)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (waIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(waIntent)
                    val label = recipientHint?.let { " for $it" } ?: ""
                    return@withContext ToolExecutionResult.Success(
                        summary = "Opened WhatsApp with prepared draft$label. Select the contact and tap Send to approve.",
                        details = mapOf(
                            "recipient" to (recipientHint ?: "User-selected"),
                            "message" to draft,
                            "channel" to "WhatsApp"
                        )
                    )
                }

                // Safe fallback: Android Share Sheet if WhatsApp is not installed
                val shared = bridgeProvider()?.launchShareText(
                    text = draft,
                    subject = recipientHint?.let { "Message for $it" }
                ) == true
                if (shared) {
                    ToolExecutionResult.Success(
                        summary = "WhatsApp is not installed; opened Android Share Sheet with your prepared draft so you can choose a messaging app.",
                        details = mapOf("message" to draft, "channel" to "Android Share Sheet Fallback")
                    )
                } else {
                    ToolExecutionResult.Failure(
                        reason = "WhatsApp is not installed and Share Sheet could not open.",
                        fallbackSuggestion = "Copy the prepared draft text manually."
                    )
                }
            } catch (e: Exception) {
                ToolExecutionResult.Failure("Could not open WhatsApp flow: ${e.localizedMessage}")
            }
        }
    }
}

class AndroidShareSheetTool(private val bridgeProvider: () -> ToolUiBridge?) : AgentTool {
    override val name = "android_share_sheet"
    override val displayName = "Android Share Sheet"
    override val description = "Opens the native Android share chooser for text content so the user approves the destination app."
    override val inputSchema = mapOf(
        "messageText" to "Text to share",
        "title" to "Optional share subject"
    )
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = true

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val text = params.messageText?.trim()?.takeIf { it.isNotEmpty() }
            ?: params.query?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("Nothing to share.")

        val opened = withContext(Dispatchers.Main) {
            bridgeProvider()?.launchShareText(text, params.title) == true
        }
        return if (opened) {
            ToolExecutionResult.Success(
                summary = "Opened Android Share Sheet for user approval.",
                details = mapOf("sharedText" to text.take(140))
            )
        } else {
            ToolExecutionResult.Failure("Could not launch Android Share Sheet.")
        }
    }
}

class OpenCameraShareTool(private val bridgeProvider: () -> ToolUiBridge?) : AgentTool {
    override val name = "open_camera_share"
    override val displayName = "Camera Capture & Share"
    override val description = "Opens the camera so the user captures and reviews a photo, then shares it via the Android Share Sheet."
    override val inputSchema = mapOf("notes" to "Optional caption or sharing purpose")
    override val requiredPermissions = listOf(Manifest.permission.CAMERA)
    override val requiresConfirmation = true

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        if (!hasPermissions(context)) {
            return ToolExecutionResult.NeedsPermission(
                permission = Manifest.permission.CAMERA,
                rationale = "Grant Camera permission to capture a photo for review and sharing (or pick an existing photo via the zero-permission Photo Picker)."
            )
        }

        val bridge = bridgeProvider()
            ?: return ToolExecutionResult.Failure("Camera UI launcher is unavailable.")

        val caption = params.notes?.trim()?.takeIf { it.isNotEmpty() }
            ?: params.messageText?.trim()?.takeIf { it.isNotEmpty() }
            ?: "Captured via D.N. Mark 1"

        val launched = withContext(Dispatchers.Main) {
            bridge.requestCameraCapture(caption)
        }
        return if (launched) {
            ToolExecutionResult.Success(
                summary = "Camera launched. Capture your photo to review it in-app and open the Android Share Sheet.",
                details = mapOf("caption" to caption)
            )
        } else {
            ToolExecutionResult.Failure(
                reason = "Unable to launch camera capture on this device.",
                fallbackSuggestion = "Try selecting a photo via the Android Photo Picker."
            )
        }
    }
}

class CreateReminderTool(
    private val firestoreRepository: Mark1FirestoreRepository
) : AgentTool {
    override val name = "create_reminder"
    override val displayName = "Save Approved Reminder"
    override val description = "Saves a user-approved reminder to Cloud Firestore and posts a confirmation alert."
    override val inputSchema = mapOf(
        "title" to "Reminder title",
        "timeLabel" to "Schedule label (e.g., Today 6:00 PM)",
        "notes" to "Optional notes"
    )
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = true

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val title = params.title?.trim()?.takeIf { it.isNotEmpty() }
            ?: params.query?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("Reminder title is required.")
        val timeLabel = params.timeLabel?.trim()?.takeIf { it.isNotEmpty() } ?: "Today"

        val result = firestoreRepository.createReminder(
            userId = params.userId,
            title = title,
            notes = params.notes,
            scheduledTimeLabel = timeLabel
        )
        return result.fold(
            onSuccess = { reminderId ->
                ToolExecutionResult.Success(
                    summary = "Reminder saved: \"$title\" ($timeLabel).",
                    details = mapOf("reminderId" to reminderId, "time" to timeLabel)
                )
            },
            onFailure = { error ->
                ToolExecutionResult.Failure(
                    reason = "Failed to save reminder: ${error.localizedMessage ?: "Firestore error"}"
                )
            }
        )
    }
}

class CreateLocalTaskTool(
    private val firestoreRepository: Mark1FirestoreRepository
) : AgentTool {
    override val name = "create_local_task"
    override val displayName = "Save Day-Plan Task"
    override val description = "Saves an approved daily action item or priority task into the user's synced checklist."
    override val inputSchema = mapOf(
        "title" to "Task title",
        "timeLabel" to "Target slot (e.g., Morning, 2:00 PM)",
        "notes" to "Priority or details"
    )
    override val requiredPermissions = emptyList<String>()
    override val requiresConfirmation = true

    override suspend fun execute(context: Context, params: ToolParams): ToolExecutionResult {
        val title = params.title?.trim()?.takeIf { it.isNotEmpty() }
            ?: params.query?.trim()?.takeIf { it.isNotEmpty() }
            ?: return ToolExecutionResult.Failure("Task title is required.")
        val slot = params.timeLabel?.trim()?.takeIf { it.isNotEmpty() } ?: "Day Plan"

        val result = firestoreRepository.createReminder(
            userId = params.userId,
            title = title,
            notes = params.notes,
            scheduledTimeLabel = slot
        )
        return result.fold(
            onSuccess = { id ->
                ToolExecutionResult.Success(
                    summary = "Day-plan task saved: \"$title\" [$slot].",
                    details = mapOf("taskItemId" to id, "slot" to slot)
                )
            },
            onFailure = { err ->
                ToolExecutionResult.Failure("Failed to save task item: ${err.localizedMessage}")
            }
        )
    }
}
