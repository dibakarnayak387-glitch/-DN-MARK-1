package com.example

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.ai.GeminiAgentBrain
import com.example.ai.LanguageDetector
import com.example.data.local.CachedMemoryEntity
import com.example.data.local.CachedStepEntity
import com.example.data.local.Mark1Database
import com.example.data.model.AgentIntentType
import com.example.data.model.AgentLanguage
import com.example.data.model.LanguagePreference
import com.example.data.model.StepStatus
import com.example.data.remote.Mark1FirestoreRepository
import com.example.data.remote.OpenMeteoClient
import com.example.tools.AndroidToolRegistry
import com.example.tools.CheckBatteryTool
import com.example.tools.CheckChargingStatusTool
import com.example.tools.GetDeviceInfoTool
import com.example.tools.ToolExecutionResult
import com.example.tools.ToolParams
import com.example.voice.VoiceController
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Mark1WorkflowTests {

    private lateinit var context: Context
    private lateinit var db: Mark1Database

    @Before
    fun setup() {
        context = ApplicationProvider.getApplicationContext()
        if (FirebaseApp.getApps(context).isEmpty()) {
            FirebaseApp.initializeApp(
                context,
                FirebaseOptions.Builder()
                    .setApplicationId("1:1234567890:android:testmark1")
                    .setApiKey("AIzaSyTestKeyForUnitTestsOnly")
                    .setProjectId("demo-no-project")
                    .build()
            )
        }
        db = Room.inMemoryDatabaseBuilder(context, Mark1Database::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun teardown() {
        db.close()
    }

    @Test
    fun `app identity and resources match D N Mark 1`() {
        assertEquals("D.N. Mark 1", context.getString(R.string.app_name))
        assertEquals("Sign in with Google", context.getString(R.string.sign_in_with_google))
    }

    @Test
    fun `language detector supports English Hindi and Odia scripts and hints`() {
        assertEquals(
            AgentLanguage.ENGLISH,
            LanguageDetector.resolveLanguage("Check my battery and weather", LanguagePreference.AUTO)
        )
        assertEquals(
            AgentLanguage.HINDI,
            LanguageDetector.resolveLanguage("जार्विस मेरी बैटरी और मौसम बताओ", LanguagePreference.AUTO)
        )
        assertEquals(
            AgentLanguage.HINDI,
            LanguageDetector.resolveLanguage("Mera battery aur mausam batao", LanguagePreference.AUTO)
        )
        assertEquals(
            AgentLanguage.ODIA,
            LanguageDetector.resolveLanguage("ଜାର୍ଭିସ୍ ମୋର ବ୍ୟାଟେରୀ ଏବଂ ପାଣିପାଗ କୁହ", LanguagePreference.AUTO)
        )
        assertEquals(
            AgentLanguage.ODIA,
            LanguageDetector.resolveLanguage("Namaskar, aaji panipaga kemiti achhi?", LanguagePreference.AUTO)
        )
        assertEquals(
            AgentLanguage.ODIA,
            LanguageDetector.resolveLanguage("Hello", LanguagePreference.ODIA)
        )
    }

    @Test
    fun `wake phrase Jarvis extraction works across English Hindi and Odia`() {
        assertEquals(
            "check my battery",
            VoiceController.extractWakePhraseCommand("Jarvis, check my battery", requireWakePhrase = true)
        )
        assertEquals(
            "मेरा मौसम बताओ",
            VoiceController.extractWakePhraseCommand("जार्विस मेरा मौसम बताओ", requireWakePhrase = true)
        )
        assertEquals(
            "ମୋର ବ୍ୟାଟେରୀ କୁହ",
            VoiceController.extractWakePhraseCommand("ଜାର୍ଭିସ୍ ମୋର ବ୍ୟାଟେରୀ କୁହ", requireWakePhrase = true)
        )
        assertNull(
            VoiceController.extractWakePhraseCommand("Random background chatter", requireWakePhrase = true)
        )
        assertEquals(
            "Open YouTube",
            VoiceController.extractWakePhraseCommand("Open YouTube", requireWakePhrase = false)
        )
    }

    @Test
    fun `battery charging and device info tools execute and verify cleanly`() = runTest {
        val batteryIntent = Intent(Intent.ACTION_BATTERY_CHANGED).apply {
            putExtra(BatteryManager.EXTRA_LEVEL, 82)
            putExtra(BatteryManager.EXTRA_SCALE, 100)
            putExtra(BatteryManager.EXTRA_TEMPERATURE, 315)
            putExtra(BatteryManager.EXTRA_VOLTAGE, 4120)
            putExtra(BatteryManager.EXTRA_HEALTH, BatteryManager.BATTERY_HEALTH_GOOD)
            putExtra(BatteryManager.EXTRA_STATUS, BatteryManager.BATTERY_STATUS_CHARGING)
            putExtra(BatteryManager.EXTRA_PLUGGED, BatteryManager.BATTERY_PLUGGED_AC)
        }
        context.sendStickyBroadcast(batteryIntent)

        val batteryRes = CheckBatteryTool().execute(context, ToolParams(userId = "u1"))
        assertTrue(batteryRes is ToolExecutionResult.Success)
        assertTrue((batteryRes as ToolExecutionResult.Success).summary.contains("82%"))

        val chargeRes = CheckChargingStatusTool().execute(context, ToolParams(userId = "u1"))
        assertTrue(chargeRes is ToolExecutionResult.Success)
        assertTrue((chargeRes as ToolExecutionResult.Success).summary.contains("Charging"))

        val deviceRes = GetDeviceInfoTool().execute(context, ToolParams(userId = "u1"))
        assertTrue(deviceRes is ToolExecutionResult.Success)
        assertTrue((deviceRes as ToolExecutionResult.Success).details.containsKey("android"))
    }

    @Test
    fun `open meteo weather code descriptions map cleanly`() {
        assertEquals("Clear sky", OpenMeteoClient.describeWeatherCode(0))
        assertEquals("Rain", OpenMeteoClient.describeWeatherCode(63))
        assertEquals("Thunderstorm", OpenMeteoClient.describeWeatherCode(95))
    }

    @Test
    fun `tool registry blocks arbitrary or unregistered commands`() = runTest {
        val firestore = FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
        val registry = AndroidToolRegistry(Mark1FirestoreRepository(firestore)) { null }
        assertEquals(14, registry.allTools.size)

        val blocked = registry.executeTool(
            context = context,
            toolName = "run_shell_command",
            params = ToolParams(userId = "u1", query = "rm -rf /")
        )
        assertTrue(blocked is ToolExecutionResult.Failure)
        assertFalse((blocked as ToolExecutionResult.Failure).recoverable)
    }

    @Test
    fun `gemini planner parser handles multi-step plans confirmation gates and memory proposals`() {
        val firestore = FirebaseFirestore.getInstance(context.getString(R.string.firestore_database_id))
        val registry = AndroidToolRegistry(Mark1FirestoreRepository(firestore)) { null }
        val brain = GeminiAgentBrain(registry)

        val multiStepJson = """
            {
              "detectedLanguage": "en",
              "intentType": "EXECUTE_PLAN",
              "assistantReply": "Checking battery, weather, and searching Iron Man technology on YouTube.",
              "taskTitle": "Battery, Weather & YouTube",
              "taskDescription": "Multi-step assistant request",
              "requiresConfirmation": false,
              "steps": [
                {"title": "Check battery", "toolName": "check_battery", "requiresConfirmation": false, "expectedResult": "Battery %"},
                {"title": "Fetch weather", "toolName": "get_weather", "location": "Bhubaneswar", "requiresConfirmation": false, "expectedResult": "Weather"},
                {"title": "Search YouTube", "toolName": "youtube_search", "query": "Iron Man technology", "requiresConfirmation": false, "expectedResult": "YouTube opens"}
              ],
              "proactiveSuggestions": ["Check charging status"]
            }
        """.trimIndent()

        val parsed = brain.parsePlanJson(multiStepJson, AgentLanguage.ENGLISH)
        assertEquals(AgentIntentType.EXECUTE_PLAN, parsed.intentType)
        assertEquals(3, parsed.steps.size)
        assertFalse(parsed.requiresConfirmation)
        assertEquals("Iron Man technology", parsed.steps[2].query)

        // Sensitive WhatsApp tool must automatically enforce requiresConfirmation = true even if model sent false
        val whatsAppJson = """
            {
              "detectedLanguage": "en",
              "intentType": "EXECUTE_PLAN",
              "assistantReply": "I prepared a WhatsApp draft for Divakar Nayak. Please approve.",
              "taskTitle": "WhatsApp Draft",
              "requiresConfirmation": false,
              "steps": [
                {"title": "Prepare WhatsApp message", "toolName": "prepare_whatsapp_message", "recipient": "Divakar Nayak", "messageText": "I will call later", "requiresConfirmation": false, "expectedResult": "WhatsApp opens"}
              ],
              "memoryProposal": {
                "category": "FACT",
                "title": "Frequent contact",
                "content": "Divakar Nayak is a frequent contact."
              },
              "proactiveSuggestions": []
            }
        """.trimIndent()

        val parsedWa = brain.parsePlanJson(whatsAppJson, AgentLanguage.ENGLISH)
        assertTrue(parsedWa.requiresConfirmation)
        assertNotNull(parsedWa.memoryProposal)
        assertEquals("Frequent contact", parsedWa.memoryProposal?.title)
    }

    @Test
    fun `room persistence stores and observes steps and cached memories`() = runTest {
        db.stepDao().upsertStep(
            CachedStepEntity(
                stepKey = "t1_step_0",
                taskId = "t1",
                userId = "u1",
                stepIndex = 0,
                title = "Check Battery",
                toolName = "check_battery",
                query = null,
                appName = null,
                recipient = null,
                messageText = null,
                location = null,
                timeLabel = null,
                notes = null,
                requiredPermission = null,
                requiresConfirmation = false,
                expectedResult = "Battery %",
                status = StepStatus.VERIFIED.name,
                actualResult = "Battery is at 82%",
                errorDetail = null,
                recoveryNote = null
            )
        )
        val steps = db.stepDao().getStepsForTask("t1")
        assertEquals(1, steps.size)
        assertEquals("Battery is at 82%", steps.first().actualResult)

        db.memoryCacheDao().upsertAll(
            listOf(
                CachedMemoryEntity(
                    id = "m1",
                    userId = "u1",
                    category = "PREFERENCE",
                    title = "Language",
                    content = "Respond in Odia",
                    language = "or",
                    pinned = true
                )
            )
        )
        val memories = db.memoryCacheDao().observeCachedMemories("u1").first()
        assertEquals(1, memories.size)
        assertEquals("Respond in Odia", memories.first().content)
    }
}
